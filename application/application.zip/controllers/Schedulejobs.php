<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Schedulejobs extends Direction_Controller{
	public function __construct() {
        parent::__construct();
	}
	
	public function email(){
		$this->email->send_scheduled_emails();
	}

}
