<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jobs extends Direction_Controller {

	public function __construct() {
        parent::__construct();
        $this->lang->load('information','english');
       
    }

    
function deactivate_batches($date = date('Y-m-d')) {
    
}    
    
}
?>
