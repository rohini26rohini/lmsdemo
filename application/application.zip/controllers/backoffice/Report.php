<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends Direction_Controller {

    public function __construct() {
        parent::__construct();
        $this->lang->load('information','english');
        $module="report_management";
        check_backoffice_permission();
    }


    public function index(){ }

    public function student_report(){
        check_backoffice_permission('student_report');
        $this->data['page']="admin/student_report";
		$this->data['menu']="reports";
        $this->data['breadcrumb']="Student Report";
        $this->data['menu_item']="backoffice/student-report";
        $this->data['studentArr']=$this->student_model->get_student_list();
		$this->load->view('admin/layouts/_master',$this->data);
    }
    public function student_report_pagination(){
        $draw = intval($this->input->post("draw"));
        $start = intval($this->input->post("start"));
        $length = intval($this->input->post("length"));
        $order = $this->input->post("order");
        $col = 0;
        $dir = "";
        if(!empty($order)) {
            foreach($order as $o) {
                $col = $o['column'];
                $dir= $o['dir'];
            }
        }
        if($dir != "desc" && $dir != "desc") {
            $dir = "desc";
        }
        $columns_valid = array(
            "am_students.registration_number", 
            "am_students.name", 
            "am_students.course_id", 
            "am_students.email", 
            "am_students.contact_number", 
            "am_students.street", 
            "am_students.status"
        );
        if(!isset($columns_valid[$col])) {
            $order = null;
        } else {
            $order = $columns_valid[$col];
        }
        $list = $this->student_model->student_report_pagination($start, $length, $order, $dir);
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $rows) {
            $course=$this->common->get_name_by_id('am_classes','class_name',array("class_id"=>$rows['course_id']));
            if ($rows['status']==1){
                $status= 'Admitted';
            }
            else if($rows['status']==2) 
            {
                $status= 'Fee Paid';
            }
            else if($rows['status']==4) 
            { 
                $status= 'Batch Changed';
            }
            else if($rows['status']==5) 
            {
                $status= 'Inactive';
            }
            else if($rows['status']==0 && $rows['verified_status']==1) {
                $status= 'Payment Pending';
            }
            else 
            {
                $status= 'Registered';
            }
             if($rows['caller_id']>0) 
            { 
                $callcentre = $this->common->get_from_tablerow('cc_call_center_enquiries', array('call_id'=>$rows['caller_id']));
                     if(!empty($callcentre['call_status']))
                     {
                       $ccstatus = $callcentre['call_status'];
                         if($ccstatus==4)
                            { 
                                $blacklist_status= '<span class="inactivestatus" style="margin-top:3px;">blacklist</span>';
                            }
                     }
            }
            
            $blacklist_status="";
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $rows['registration_number'];
            $row[] = $rows['name'];
            $row[] = $course;
            $row[] = $rows['email'];
            $row[] = $rows['contact_number'];
            $row[] = $rows['street'];
            $row[] = $status." ".$blacklist_status;
            $data[] = $row;
        }
        $total_rows=$this->student_model->get_num_student_list_pagination();
        $output = array(
              "draw" => $draw,
              "recordsTotal" => $total_rows,
              "recordsFiltered" => $total_rows,
              "data" => $data
          );
        echo json_encode($output);
        exit();
    }
    
    public function search_student()
    {
         $html = '<thead><tr>
                <th width="50">'.$this->lang->line('sl_no').'</th>
                <th>'.$this->lang->line('application.no').'</th>
                <th>'.$this->lang->line('name').'</th>
                <th>'.$this->lang->line('course').'</th>
                <th>'.$this->lang->line('emailid').'</th>
                <th>'.$this->lang->line('contact.no').'</th>
                <th>'.$this->lang->line('location').'</th>
                <th>'.$this->lang->line('status').'</th>
                </tr></thead>';
        if($_POST) {
            $school_id=$this->input->post('school_id');
            $centre_id=$this->input->post('centre_id');
            $course_id=$this->input->post('course_id');
            $batch_id=$this->input->post('batch_id');
            $status=$this->input->post('status');
            $start_date=$this->input->post('start_date');
            $end_date=$this->input->post('end_date');
            $where=array();
            if($school_id != "")
            {
                $where['am_classes.school_id']=$school_id;
            }
            if($centre_id !="")
            {
                $where['am_student_course_mapping.center_id']=$centre_id;
            }
            if($course_id !="")
            {
                $where['am_student_course_mapping.institute_course_mapping_id']=$course_id;
            }
            if($batch_id !="")
            {
                $where['am_student_course_mapping.batch_id']=$batch_id;
            }
            if($status !="")
            { 
              
                if($status != "blacklist")
               {
                $where['am_students.status']=$status;
               }
              else
              {
                  
               $where['cc_call_center_enquiries.call_status']="4";
              }
            }
            if($start_date !="") {
                $where['am_students.admitted_date>=']=date('Y-m-d',strtotime($start_date));
            }
            if($end_date !="") {
                $where['am_students.admitted_date<=']=date('Y-m-d',strtotime($end_date));
            }
            $data=$this->student_model->search_student($where); 
            if(!empty($data))
            { $i=1;
                foreach($data as $row)
                {
                    $course=$this->common->get_name_by_id('am_classes','class_name',array("class_id"=>$row['course_id']));
                    $status="";
                            if ($row['student_status']==1) { $status= 'Admitted';}
                            else if($row['student_status']==2) {  $status= 'Fee Paid';}
                            else if($row['student_status']==4) {  $status= 'Batch Changed';}
                            else if($row['student_status']==5) {  $status= 'Inactive';}
                            else if($row['student_status']==0 && $row['verified_status']==1) {
                                 $status= 'Payment Pending';}
                            else  {  $status= 'Payment Pending';}
                            if($row['call_status']==4) {  $status= 'Blacklist';}
                     $html .= '<tr>
                            <td>'.$i.'</td>
                            <td>'.$row['registration_number'].'</td>
                            <td>'.$row['name'].'</td>
                            <td>'.$course.'</td>
                            <td>'.$row['email'].'</td>
                            <td>'.$row['contact_number'].'</td>
                            <td>'.$row['street'].'</td>
                            <td>'.$status.'</td>
                        </tr>';
                        $i++; 
                }
            }
        }
        echo $html;
    }
    
    /*
    
    */
    public function export_student_report() {
        if($_POST) {
            $school_id=$this->input->post('school_id');
            $centre_id=$this->input->post('centre_id');
            $course_id=$this->input->post('course_id');
            $batch_id=$this->input->post('batch_id');
            $status=$this->input->post('status');
            $start_date=$this->input->post('start_date');
            $end_date=$this->input->post('end_date');
            $type=$this->input->post('type');
            $where=array();
            if($school_id != ""){
                $where['am_classes.school_id']=$school_id;
            }
            if($centre_id !=""){
                $where['am_student_course_mapping.center_id']=$centre_id;
            }
            if($course_id !=""){
                $where['am_student_course_mapping.institute_course_mapping_id']=$course_id;
            }
            if($batch_id !=""){
                $where['am_student_course_mapping.batch_id']=$batch_id;
            }
            if($status !=""){
                if($status != "blacklist"){
                    $where['am_students.status']=$status;
                } else {  
                    $where['cc_call_center_enquiries.call_status']="4";
                }
            }
            if($start_date !=""){
                $where['am_students.admitted_date>=']=date('Y-m-d',strtotime($start_date));
            }
            if($end_date !=""){
                $where['am_students.admitted_date<=']=date('Y-m-d',strtotime($end_date));
            }
            $data['studentArr']=$this->student_model->search_student($where);
            // show($data['studentArr']);
            if(!empty($data['studentArr'])){
                if($type == 'pdf'){
                    $filename      = 'students_report.pdf';
                    $pdfFilePath = FCPATH."/uploads/".$filename; 
                    $html = $this->load->view('admin/pdf/student_report',$data,TRUE);
                    //  echo $html;die();
                    ini_set('memory_limit','512M'); // boost the memory limit if it's low ;)
                    $this->load->library('pdf');
                    $pdf = $this->pdf->load();
                    $pdf->SetWatermarkText('Direction');
                    $pdf->watermark_font = 'DejaVuSansCondensed';
                    $pdf->showWatermarkText = true;
                    $pdf->watermarkTextAlpha = 0.2;
                    $pdf->SetHeader();
                    $pdf->SetFooter('<div style="text-align:center;"></div></body></html>'); // Add a footer for good measure ;)
                    $pdf->AddPage('P');
                    $pdf->WriteHTML($html); // write the HTML into the PDF
                    //$pdf->WriteHTML('Hello World');
                    $pdf->Output($filename, "D"); // save to file because we can
                }else{
                    $filename      = 'students_report-'.date('Ymd').'.xlsx';
                    $this->load->library('excel');
                    $objPHPExcel = new PHPExcel();
                    $objPHPExcel->setActiveSheetIndex(0);
                    $objPHPExcel->getActiveSheet()->SetCellValue('A1', 'Sl.No.');
                    $objPHPExcel->getActiveSheet()->SetCellValue('B1', 'Application.No.');
                    $objPHPExcel->getActiveSheet()->SetCellValue('C1', 'Name');
                    $objPHPExcel->getActiveSheet()->SetCellValue('D1', 'School');
                    $objPHPExcel->getActiveSheet()->SetCellValue('E1', 'Centre');
                    $objPHPExcel->getActiveSheet()->SetCellValue('F1', 'Batch');       
                    $objPHPExcel->getActiveSheet()->SetCellValue('G1', 'Contact Number');       
                    $objPHPExcel->getActiveSheet()->SetCellValue('H1', 'Address');       
                    $objPHPExcel->getActiveSheet()->SetCellValue('I1', 'Location');       
                    $objPHPExcel->getActiveSheet()->SetCellValue('J1', 'Status');       
                    // set Row
                    $rowCount = 2;
                    $j = 1;
                    foreach ($data['studentArr'] as $row) {
                        $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $j);
                        $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, $row['registration_number']);
                        $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCount, $row['name']);
                        $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, $this->common->get_name_by_id('am_schools','school_name',array("school_id"=>$row['school_id'])));
                        $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, $this->common->get_name_by_id('am_institute_master','institute_name',array("institute_master_id"=>$row['center_id'])));
                        $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowCount, $this->common->get_name_by_id('am_batch_center_mapping','batch_name',array("batch_id"=>$row['batch_id'])));
                        $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowCount, $row['contact_number']);
                        $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowCount, $row['address']);
                        $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowCount, $row['street']);
                        $ccstatus = '';
                        if($row['caller_id']>0) { 
                            $callcentre = $this->common->get_from_tablerow('cc_call_center_enquiries', array('call_id'=>$row['caller_id']));
                            if(!empty($callcentre['call_status'])){
                                $ccstatus = $callcentre['call_status'];
                            } 
                        }
                        if ($row['student_status']==1) { $status1 = 'Admitted';}
                        else if($row['student_status']==2) { $status1 = 'Fee Paid';}
                        else if($row['student_status']==4) { $status1 = 'Batch Changed';}
                        else if($row['student_status']==5) { $status1 = 'Inactive';}
                        else if($row['student_status']==0 && $row['verified_status']==1) { $status1 = 'Payment Pending';}
                        else  { $status1 = 'Payment Pending';}
                        if($ccstatus==4) { $status1 = 'Blacklist';}
                        $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowCount, $status1);
                        $rowCount++;
                        $j++;
                    }
                    
                    header("Content-Type: application/vnd.ms-excel");
                    header("Content-Disposition: attachment; filename=".$filename);
                    header("Cache-Control: max-age=0");
                    $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
                    $objWriter->save(FCPATH.'uploads/samples/'.$filename);
                    redirect(base_url('uploads/samples/'.$filename));
                }
            }else{
                $this->session->set_flashdata('item','No records found..!'); 
                redirect('backoffice/student-report'); 
            }
        }
    }
    
   public function staff_attendance_report()
    {
        check_backoffice_permission('staff_attendance_report');
        $this->data['page']="admin/staff_attendance_report";
		$this->data['menu']="reports";
        $this->data['breadcrumb']="Student Report";
        $this->data['menu_item']="staff_attendance_report";
		$this->load->view('admin/layouts/_master',$this->data);
    }
    
    public function load_staff_attendance()
    {
      if($_POST)
      {
          $start_date=date('Y-m-d',strtotime($this->input->post('start_date')));
          $end_date=date('Y-m-d',strtotime($this->input->post('end_date')));
          $attendance_data=$this->Report_model->load_staff_attendance($start_date,$end_date);
          //echo '<pre>';print_r($attendance_data);//die();
          $date_array=array();
         foreach($attendance_data as $key=>$row)
         {
            $date_array[$key]=$row['date']; 
         }
          $date_array=array_unique($date_array);
          $html='<table  class="table table-striped table-sm" style="width:100%">
                <thead>
                    <tr>
                        <th width="50">'. $this->lang->line("sl_no").'</th>
                        <th>'. $this->lang->line("name").'</th>
                        <th>'.  $this->lang->line("role").'</th>
                        <th>'. $this->lang->line("attendance").'</th></tr>
                </thead>
               <tbody>';
         foreach($date_array as $row)
         {//echo '<pre>'.print_r($row);
           //echo $row."<br>";
             $html.='<tr><td colspan="4" class="text-center s-attendance">'.date('d-m-Y',strtotime($row)).'</td><tr>';
             $i=1; 
             foreach($attendance_data as $val)
             { 
                if($val['date'] == $row)
                {
                     if($val['attendance'] == 0)
                     {
                         $attendance="<span><i class='fa fa-times text-danger'></i></span>";
                       
                     }
                    else
                    {
                       $attendance="<span><i class='fa fa-check text-success'></i></span>";  
                    }
                   $html.='<tr>
                           <td>'.$i.'</td>
                           <td>'.$val['name'].'</td>
                           <td>'.$val['role_name'].'</td>
                           <td>'.$attendance.'</td>
                           <tr>';
					$i++;
                }
               //$i++;
             }
         }
          $html.='</tbody></table>';
          echo $html;
        }
    
    }
    
    public function export_staff_attendance_report(){
        if($_POST)
        {
            $start_date=date('Y-m-d',strtotime($this->input->post('start_date')));
            $end_date=date('Y-m-d',strtotime($this->input->post('end_date')));
            $data['attendance_data']=$this->Report_model->load_staff_attendance($start_date,$end_date);
            foreach($data['attendance_data'] as $key=>$row) {
                $date_array[$key]=$row['date']; 
            }
            $data['date_array']=array_unique($date_array);
            if(!empty($data)) {
                $filename      = 'staff_attendance_report.pdf';
                $pdfFilePath = FCPATH."/uploads/".$filename; 
                $html = $this->load->view('admin/pdf/staff_attendance_report',$data,TRUE);
                ini_set('memory_limit','512M'); // boost the memory limit if it's low ;)
                $this->load->library('pdf');
                $pdf = $this->pdf->load();
                $pdf->SetFooter('<div style="text-align:center;"></div></body>
                </html>'); // Add a footer for good measure ;)
                $pdf->AddPage('L');
                $pdf->WriteHTML($html); // write the HTML into the PDF
                //$pdf->WriteHTML('Hello World');
                $pdf->Output($filename, "D"); // save to file because we can
               
            }
           
        }
    }
    public function batch_schedule_report(){
        check_backoffice_permission('batch_schedule_report');
        $this->data['page'] = "admin/batch_schedule_report";
		$this->data['menu'] = "reports";
        $this->data['breadcrumb'] = "Batch Schedule Report";
        $this->data['menu_item'] = "batch-schedule-report";
        $this->data['batchArr']=$this->Report_model->get_batch_schedule_report();
        // show($this->data['batchArr']);
		$this->load->view('admin/layouts/_master',$this->data);
    }
    public function search_batch() {
        $html = '<thead>
                    <tr>
                        <th>'.$this->lang->line('sl_no').'</th>
                        <th>'.$this->lang->line('batch').'</th>
                        <th>'.$this->lang->line('subject').'</th>
                        <th>'.$this->lang->line('date').'</th>
                        <th>'.$this->lang->line('start_time').'</th>
                        <th>'.$this->lang->line('end_time').'</th> 
                        <th>'.$this->lang->line('module_name').'</th>
                        <th>'.$this->lang->line('staff').'</th>
                        <th>'.$this->lang->line('status').'</th>
                    </tr>
                </thead><tbody>';
        if($_POST) {
            $batch_id = $this->input->post('batch_id');
            $status = $this->input->post('status');
            $start_date = $this->input->post('start_date');
            $end_date = $this->input->post('end_date');
            $subject = $this->input->post('filter_subject');
            $where = array();
            if($status !=""){    
               $where['am_schedules.class_taken'] = $status;
            }
            if($start_date !=""){
                $where['am_schedules.schedule_date>=']=date('Y-m-d',strtotime($start_date));
            }
            if($end_date !=""){
                $where['am_schedules.schedule_date<=']=date('Y-m-d',strtotime($end_date));
            }
            if($subject != ""){
                $where['am_syllabus_master_details.subject_master_id'] = $subject;
            }
            if($batch_id != ""){
                $where['am_batch_center_mapping.batch_id'] = $batch_id;
            }
            $data = $this->Report_model->search_batch($where);
            if(!empty($data))
            { $i=1;
                foreach($data as $row) {
                    $html .= '<tr>
                        <td>'.$i.'</td>
                        <td>'.$this->common->get_name_by_id('am_batch_center_mapping','batch_name',array("batch_id"=>$row['batch_id'])).'</td>
                        <td>'.$this->common->get_name_by_id('mm_subjects','subject_name',array("subject_id"=>$row['subject_master_id'])).'</td>
                        <td>'.date('d-m-Y',strtotime($row['schedule_date'])).'</td>
                        <td>'.date("g:i a", strtotime($row['schedule_start_time'])).'</td>
                        <td>'.date("g:i a", strtotime($row['schedule_end_time'])).'</td>
                        <td>'.$this->common->get_module_fromschedule_idname_by_id($row['module_id']).'</td>
                        <td>'.$this->common->get_name_by_id('am_staff_personal','name',array("personal_id"=>$row['staff_id'])).'</td>
                        <td>';
                            if($row['class_taken'] == 1){
                                $html .= 'Completed';
                            }else{
                                $html .= 'Pending';
                            }
                    $html .= '</td>
                    </tr>';
                    $i++; 
                }
                $html .= '</tbody>';
            }
        }
        echo $html;
    }
    public function export_batch_report() {
        if($_POST) {
            $batch_id=$this->input->post('batch_id');
            $status=$this->input->post('status');
            $start_date=$this->input->post('start_date');
            $end_date=$this->input->post('end_date');
            $subject=$this->input->post('subject');
            $type1=$this->input->post('type1');
            $where = array();
            if($status !=""){    
               $where['am_schedules.class_taken'] = $status;
            }
            if($start_date !=""){
                $where['am_schedules.schedule_date>=']=date('Y-m-d',strtotime($start_date));
            }
            if($end_date !=""){
                $where['am_schedules.schedule_date<=']=date('Y-m-d',strtotime($end_date));
            }
            if($subject != ""){
                $where['am_syllabus_master_details.subject_master_id'] = $subject;
            }
            if($batch_id != ""){
                $where['am_batch_center_mapping.batch_id'] = $batch_id;
            }
            $data['report'] = $this->Report_model->search_batch($where);
            // show($this->db->last_query());
            if(!empty($data['report'])){
                if($type1 == 'pdf'){
                    $filename      = 'batch_report.pdf';
                    $pdfFilePath = FCPATH."/uploads/".$filename; 
                    $html = $this->load->view('admin/pdf/batch_report',$data,TRUE);
                    //  echo $html;die();
                    ini_set('memory_limit','512M'); // boost the memory limit if it's low ;)
                    $this->load->library('pdf');
                    $pdf = $this->pdf->load();
                    $pdf->SetWatermarkText('Direction');
                    $pdf->watermark_font = 'DejaVuSansCondensed';
                    $pdf->showWatermarkText = true;
                    $pdf->watermarkTextAlpha = 0.2;
                    // $pdf->SetHeader('Content-Type: application/pdf');
                    $pdf->SetFooter('<div style="text-align:center;"></div></body>
                    </html>'); // Add a footer for good measure ;)
                    $pdf->AddPage('p');
                    $pdf->WriteHTML($html); // write the HTML into the PDF
                    //$pdf->WriteHTML('Hello World');
                    $pdf->Output($filename, "D"); // save to file because we can
                }else{
                    $filename      = 'batch_report-'.date('Ymd').'.xlsx';
                    $objPHPExcel = new PHPExcel();
                    $objPHPExcel->setActiveSheetIndex(0);
                    $objPHPExcel->getActiveSheet()->SetCellValue('A1', $this->lang->line('sl_no'));
                    $objPHPExcel->getActiveSheet()->SetCellValue('B1', $this->lang->line('batch'));
                    $objPHPExcel->getActiveSheet()->SetCellValue('C1', $this->lang->line('subject'));
                    $objPHPExcel->getActiveSheet()->SetCellValue('D1', $this->lang->line('date'));
                    $objPHPExcel->getActiveSheet()->SetCellValue('E1', $this->lang->line('start_time'));
                    $objPHPExcel->getActiveSheet()->SetCellValue('F1', $this->lang->line('end_time'));
                    $objPHPExcel->getActiveSheet()->SetCellValue('G1', $this->lang->line('module_name'));             
                    $objPHPExcel->getActiveSheet()->SetCellValue('H1', $this->lang->line('staff'));             
                    $objPHPExcel->getActiveSheet()->SetCellValue('I1', $this->lang->line('status'));     
                    // set Row
                    $rowCount = 2;
                    $j = 1;
                    foreach ($data['report'] as $row) { if($row['schedule_type'] == 1) $type = 'Exam'; else $type = 'Class';
                        $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $j);
                        $batch = $this->common->get_name_by_id('am_batch_center_mapping','batch_name',array("batch_id"=>$row['batch_id']));
                        $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, $batch);
                        $subject = $this->common->get_name_by_id('mm_subjects','subject_name',array("subject_id"=>$row['subject_master_id']));
                        $objPHPExcel->getActiveSheet()->SetCellValue('c' . $rowCount, $subject);
                        $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, date('d-m-Y',strtotime($row['schedule_date'])));
                        $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, date("g:i a", strtotime($row['schedule_start_time'])));
                        $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowCount, date("g:i a", strtotime($row['schedule_end_time'])));
                            $moduleExam = $this->common->get_module_fromschedule_idname_by_id($row['module_id']);
                        $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowCount, $moduleExam);
                            $staff = $this->common->get_name_by_id('am_staff_personal','name',array("personal_id"=>$row['staff_id']));
                        $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowCount, $staff);
                        if($row['class_taken'] == 1){
                            $status = 'Completed';
                        }else{
                            $status = 'Pending';
                        }
                        $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowCount, $status);
                        $rowCount++;
                        $j++;
                    }
                    
                    header("Content-Type: application/vnd.ms-excel");
                    header("Content-Disposition: attachment; filename=".$filename);
                    header("Cache-Control: max-age=0");
                    $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
                    $objWriter->save(FCPATH.'uploads/samples/'.$filename);
                    redirect(base_url('uploads/samples/'.$filename));
                }
            }
        }
    }
    public function get_subject(){
        $batchId = $this->input->post('batch_id');
        $subjectArr = $this->Report_model->get_subject($batchId);
        // show($subjectArr);
        $html = '<option value="">'.$this->lang->line("select").'</option>';
        if(!empty($subjectArr)){
             foreach($subjectArr as $row){
                $html .= '<option value="'.$row["subject_id"].'">'.$row["subject_name"].'</option>';
            }
        }
        echo $html;
    }

    public function facualty_allocated_report(){
        check_backoffice_permission('facualty_allocated_report');
        $this->data['page'] = "admin/facualty_allocated_report";
		$this->data['menu'] = "reports";
        $this->data['breadcrumb'] = "Facualty Allocated Report";
        $this->data['menu_item'] = "facualty-allocated-report";
        // $this->data['batchArr']=$this->Report_model->get_batch_schedule_report();/
        // show($this->data['batchArr']);
		$this->load->view('admin/layouts/_master',$this->data);
    }

    public function search_faculty_allocation() {
        $html = '<thead>
                    <tr>
                        <th width="50">'.$this->lang->line('sl_no').'</th>
                        <th>'.$this->lang->line('batch').'</th>
                        <th>'.$this->lang->line('centre').'</th>
                        <th>'.$this->lang->line('date').'</th>
                        <th>'.$this->lang->line('start_time').'</th>
                        <th>'.$this->lang->line('end_time').'</th> 
                        <th>'.$this->lang->line('module_name').'</th>
                        <th>'.$this->lang->line('status').'</th>
                    </tr>
                </thead><tbody>';
        if($_POST) {
            $faculty_id = $this->input->post('faculty_id');
            $batch_id = $this->input->post('batch_id');
            $status = $this->input->post('status');
            $start_date = $this->input->post('start_date');
            $end_date = $this->input->post('end_date');
            $where = array();
            if($status !=""){    
               $where['am_schedules.class_taken'] = $status;
            }
            if($start_date !=""){
                $where['am_schedules.schedule_date>=']=date('Y-m-d',strtotime($start_date));
            }
            if($end_date !=""){
                $where['am_schedules.schedule_date<=']=date('Y-m-d',strtotime($end_date));
            }
            if($faculty_id != ""){
                $where['am_schedules.staff_id'] = $faculty_id;
            }
            if($batch_id != ""){
                $where['am_batch_center_mapping.batch_id'] = $batch_id;
            }
            $data = $this->Report_model->get_faculty_schedule_report($where);
            // show($data);
            // show($this->db->last_query());
            if(!empty($data))
            { $i=1;
                foreach($data as $row) {
                    $html .= '<tr>
                        <td>'.$i.'</td>
                        <td>'.$this->common->get_name_by_id('am_batch_center_mapping','batch_name',array("batch_id"=>$row['batch_id'])).'</td>
                        <td>'.$row['institute_name'].'</td>
                        <td>'.date('d-m-Y',strtotime($row['schedule_date'])).'</td>
                        <td>'.date("g:i a", strtotime($row['schedule_start_time'])).'</td>
                        <td>'.date("g:i a", strtotime($row['schedule_end_time'])).'</td>
                        <td>'.$this->common->get_module_fromschedule_idname_by_id($row['module_id']).'</td>
                        <td>';
                            if($row['class_taken'] == 1){
                                $html .= 'Completed';
                            }else{
                                $html .= 'Pending';
                            }
                    $html .= '</td>
                    </tr>';
                    $i++; 
                }
                $html .= '</tbody>';
            }
        }
        echo $html;
    }

    public function export_faculty_report() { 
        if($_POST) {
            $faculty_id=$this->input->post('faculty_id');
            $batch_id=$this->input->post('batch_id');
            $status=$this->input->post('status');
            $start_date=$this->input->post('start_date');
            $end_date=$this->input->post('end_date');
            $type=$this->input->post('type');
            // show($type);
            $where = array();
            if($status !=""){    
               $where['am_schedules.class_taken'] = $status;
            }
            if($start_date !=""){
                $where['am_schedules.schedule_date>=']=date('Y-m-d',strtotime($start_date));
            }
            if($end_date !=""){
                $where['am_schedules.schedule_date<=']=date('Y-m-d',strtotime($end_date));
            }
            if($faculty_id != ""){
                $where['am_schedules.staff_id'] = $faculty_id;
            }
            if($batch_id != ""){
                $where['am_batch_center_mapping.batch_id'] = $batch_id;
            }
            $data['report'] = $this->Report_model->get_faculty_schedule_report($where);
            // show($this->db->last_query());
            if(!empty($data['report'])){
                if($type == 'pdf'){
                    $filename      = 'faculty_report-'.date('Ymd').'.pdf';
                    $pdfFilePath = FCPATH."/uploads/".$filename; 
                    $html = $this->load->view('admin/pdf/faculty_report',$data,TRUE);
                    //  echo $html;die();
                    ini_set('memory_limit','512M'); // boost the memory limit if it's low ;)
                    $this->load->library('pdf');
                    $pdf = $this->pdf->load();
                    $pdf->SetWatermarkText('Direction');
                    $pdf->watermark_font = 'DejaVuSansCondensed';
                    $pdf->showWatermarkText = true;
                    $pdf->watermarkTextAlpha = 0.2;
                    // $pdf->SetHeader('Content-Type: application/pdf');
                    $pdf->SetFooter('<div style="text-align:center;"></div></body>
                    </html>'); // Add a footer for good measure ;)
                    $pdf->AddPage('p');
                    $pdf->WriteHTML($html); // write the HTML into the PDF
                    //$pdf->WriteHTML('Hello World');
                    $pdf->Output($filename, "D"); // save to file because we can
                }else{
                    $filename      = 'faculty_report-'.date('Ymd').'.xlsx';
                    $this->load->library('excel');
                    $objPHPExcel = new PHPExcel();
                    $objPHPExcel->setActiveSheetIndex(0);
                    $objPHPExcel->getActiveSheet()->SetCellValue('A1', $this->lang->line('sl_no'));
                    $objPHPExcel->getActiveSheet()->SetCellValue('B1', $this->lang->line('batch'));
                    $objPHPExcel->getActiveSheet()->SetCellValue('C1', $this->lang->line('centre'));
                    $objPHPExcel->getActiveSheet()->SetCellValue('D1', $this->lang->line('date'));
                    $objPHPExcel->getActiveSheet()->SetCellValue('E1', $this->lang->line('start_time'));
                    $objPHPExcel->getActiveSheet()->SetCellValue('F1', $this->lang->line('end_time'));           
                    $objPHPExcel->getActiveSheet()->SetCellValue('G1', $this->lang->line('module_name'));           
                    $objPHPExcel->getActiveSheet()->SetCellValue('H1', $this->lang->line('status'));
                    $rowCount = 2;
                    $j = 1;
                    foreach ($data['report'] as $row) { if($row['schedule_type'] == 1) $type = 'Exam'; else $type = 'Class';
                        $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $j);
                        $batch = $this->common->get_name_by_id('am_batch_center_mapping','batch_name',array("batch_id"=>$row['batch_id']));
                        $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, $batch);
                        $objPHPExcel->getActiveSheet()->SetCellValue('c' . $rowCount, $row['institute_name']);
                        $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, date('d-m-Y',strtotime($row['schedule_date'])));
                        $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, date("g:i a", strtotime($row['schedule_start_time'])));
                        $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowCount, date("g:i a", strtotime($row['schedule_end_time'])));
                        $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowCount, $this->common->get_module_fromschedule_idname_by_id($row['module_id']));
                        if($row['class_taken'] == 1){
                            $status = 'Completed';
                        }else{
                            $status = 'Pending';
                        }
                        $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowCount, $status);
                        $rowCount++;
                        $j++;
                    }
                    
                    header("Content-Type: application/vnd.ms-excel");
                    header("Content-Disposition: attachment; filename=".$filename);
                    header("Cache-Control: max-age=0");
                    $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
                    $objWriter->save(FCPATH.'uploads/samples/'.$filename);
                    redirect(base_url('uploads/samples/'.$filename));
                }
            }else{
                $this->session->set_flashdata('item','No records found..!'); 
                redirect('backoffice/facualty-allocated-report'); 
            }
        }
    }

    public function staff_leave_report(){
        check_backoffice_permission('staff_leave_report');
        $this->data['page'] = "admin/staff_leave_report";
		$this->data['menu'] = "reports";
        $this->data['breadcrumb'] = "Staff Leave Report";
        $this->data['menu_item'] = "staff-leave-report";
        $this->data['staff'] = $this->Report_model->get_staff();
        // show($this->data['staff']);
		$this->load->view('admin/layouts/_master',$this->data);
    }

    public function search_leave() {
        $html = '<thead><tr>
                    <th width="20">'.$this->lang->line('sl_no').'</th>
                    <th>'.$this->lang->line('staff').'</th>';
                    $leaveHeads = $this->common->get_alldata('leave_heads',array("status"=>1));
                    foreach($leaveHeads as $head){
                        $html .= '<th>'.$head['head'].'</th>';
                    }
        $html .= '<th>'.$this->lang->line('total').'</th>';
                $html .= '</tr>
                        </thead><tbody>';
        if($_POST) {
            $faculty_id = $this->input->post('faculty_id');
            $start_date = $this->input->post('start_date');
            $end_date = $this->input->post('end_date');
            $where = array();
            if($start_date !=""){
                $start_date = date('Y-m-d',strtotime($start_date));
            }
            if($end_date !=""){
                $end_date = date('Y-m-d',strtotime($end_date));
            }
            if($faculty_id != ""){
                $where['am_staff_personal.personal_id'] = $faculty_id;
            }
            $data = $this->Report_model->get_staffSearch($where);
            // show($this->db->last_query());
            if(!empty($data))
            { $i=1;
                foreach($data as $row) {
                    $html .= '<tr> 
                                <td>'.$i.'</td>
                                <td>'.$row['name'].'</td>';
                                $leaveHeads = $this->common->get_alldata('leave_heads',array("status"=>1));
                                    foreach($leaveHeads as $head){
                                        $html .= '<td>'.$this->common->get_leaveBystaff($row['personal_id'], $head['id'], $start_date, $end_date).'</td>';
                                    }
                    $html .= '<td>'.$this->common->get_leaveBystaff_total($row['personal_id'], $start_date, $end_date).'</td>';
                    $html .= '</tr>';
                    $i++; 
                }
                $html .= '</tbody>';
            }
        }
        echo $html;
    }
    public function export_leave_report() {
        if($_POST) {
            $faculty_id=$this->input->post('faculty_id');
            $start_date=$this->input->post('start_date');
            $end_date=$this->input->post('end_date');
            $type=$this->input->post('type');
            // show($type);
            $where = array();
            if($start_date !=""){
                $start_date = date('Y-m-d',strtotime($start_date));
            }
            if($end_date !=""){
                $end_date = date('Y-m-d',strtotime($end_date));
            }
            if($faculty_id != ""){
                $where['am_staff_personal.personal_id'] = $faculty_id;
            }
            $data['report'] = $this->Report_model->get_staffSearch($where);
            $data['start_date'] = $start_date;
            $data['end_date'] = $end_date;
            // show($this->db->last_query());
            if(!empty($data['report'])){
                if($type == 'pdf'){
                    $filename      = 'leave_report-'.date('Ymd').'.pdf';
                    $pdfFilePath = FCPATH."/uploads/".$filename; 
                    $html = $this->load->view('admin/pdf/leave_report',$data,TRUE);
                    //  echo $html;die();
                    ini_set('memory_limit','512M'); // boost the memory limit if it's low ;)
                    $this->load->library('pdf');
                    $pdf = $this->pdf->load();
                    $pdf->SetWatermarkText('Direction');
                    $pdf->watermark_font = 'DejaVuSansCondensed';
                    $pdf->showWatermarkText = true;
                    $pdf->watermarkTextAlpha = 0.2;
                    // $pdf->SetHeader('Content-Type: application/pdf');
                    $pdf->SetFooter('<div style="text-align:center;"></div></body>
                    </html>'); // Add a footer for good measure ;)
                    $pdf->AddPage('p');
                    $pdf->WriteHTML($html); // write the HTML into the PDF
                    //$pdf->WriteHTML('Hello World');
                    $pdf->Output($filename, "D"); // save to file because we can
                }else{
                    $filename      = 'faculty_report-'.date('Ymd').'.xlsx';
                    $letters = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
                    $this->load->library('excel');
                    $objPHPExcel = new PHPExcel();
                    $objPHPExcel->setActiveSheetIndex(0);
                    $objPHPExcel->getActiveSheet()->SetCellValue('A1', $this->lang->line('sl_no'));
                    $objPHPExcel->getActiveSheet()->SetCellValue('B1', $this->lang->line('staff'));
                    $leaveHeads = $this->common->get_alldata('leave_heads',array("status"=>1));
                    $key = 2;
                    foreach($leaveHeads as $head){
                        $objPHPExcel->getActiveSheet()->SetCellValue($letters[$key].'1', $head['head']);
                        $key++;
                    }
                    $objPHPExcel->getActiveSheet()->SetCellValue($letters[$key].'1', $this->lang->line('total'));
                    $rowCount = 2;
                    $j = 1;
                    foreach ($data['report'] as $row) {
                        $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $j);
                        $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, $row['name']);
                        $key = 2;
                        foreach($leaveHeads as $head){
                            $objPHPExcel->getActiveSheet()->SetCellValue($letters[$key] . $rowCount, $this->common->get_leaveBystaff($row['personal_id'], $head['id'],$start_date,$end_date));
                            $key++;
                        }
                        $objPHPExcel->getActiveSheet()->SetCellValue($letters[$key] . $rowCount, $this->common->get_leaveBystaff_total($row['personal_id'],$start_date,$end_date));
                        $rowCount++;
                        $j++;
                    }
                    
                    header("Content-Type: application/vnd.ms-excel");
                    header("Content-Disposition: attachment; filename=".$filename);
                    header("Cache-Control: max-age=0");
                    $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
                    $objWriter->save(FCPATH.'uploads/samples/'.$filename);
                    redirect(base_url('uploads/samples/'.$filename));
                }
            }
        }
    }
}
?>
