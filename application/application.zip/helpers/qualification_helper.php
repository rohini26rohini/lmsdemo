<?php
    function get_all_qualifications(){
        return '<option value="">Others</option>
                <option  >AHSLC</option>
                <option  >Anglo Indian School Leaving Certificate</option>
                <option  >CBSE Xth</option>
                <option  >ICSE Xth</option>
                <option  >JTSLC</option>
                <option  >Matriculation Certificate</option>
                <option  >Secondary School Examination</option>
                <option  >SSC</option>
                <option  >SSLC</option>
                <option  >SSLC with Agricultural Optional</option>
                <option  >Standard X Equivalency</option>
                <option  >THSLC Xth</option>
                <option  >AHSS</option>
                <option  >CBSE XIIth</option>
                <option  >ICSE XIIth</option>
                <option  >Plus 2</option>
                <option  >Plus Two Equivalency</option>
                <option  >Pre Degree</option>
                <option  >Pre University</option>
                <option  >Senior Secondary School Examination</option>
                <option  >SSSC</option>
                <option  >THSE - XII</option>
                <option  >VHSE</option>
                <option  >VHSE Pass in Trade only for Employment Purpose</option>
                <option >B Voc</option>
                <option  >BA</option>
                <option  >BA Honours</option>
                <option  >Bachelor of Audiology and Speech Language Pathology(BASLP)</option>
                <option  >Bachelor of BusineesAdministration&amp;Bachelor of Laws(Honours)</option>
                <option  >Bachelor of Design</option>
                <option  >Bachelor of Divinity</option>
                <option  >Bachelor of Occupational Therapy - BOT</option>
                <option  >Bachelor of Science BS</option>
                <option  >Bachelor of Science in Applied Sciences</option>
                <option  >Bachelor of Textile</option>
                <option  >BAL</option>
                <option  >BAM</option>
                <option  >BAMS</option>
                <option  >BArch</option>
                <option  >BBA</option>
                <option  >BBM</option>
                <option  >BBS</option>
                <option  >BBS Bachelor of Business Studies</option>
                <option  >BBT</option>
                <option  >BCA</option>
                <option  >BCJ</option>
                <option  >BCom</option>
                <option  >BComHonours</option>
                <option  >BComEd</option>
                <option  >BCS - Bachelor of Corporate Secretaryship</option>
                <option  >BCVT </option>
                <option  >BDS</option>
                <option  >BE</option>
                <option  >BEd</option>
                <option  >BFA</option>
                <option  >BFA Hearing Impaired</option>
                <option  >BFSc</option>
                <option  >BFT</option>
                <option  >BHM</option>
                <option  >BHMS</option>
                <option  >BIL Bachelor of Industrial Law</option>
                <option  >BIT</option>
                <option  >BLiSc</option>
                <option  >BMMC</option>
                <option  >BMS - Bachelor of Management Studies</option>
                <option  >BNYS</option>
                <option  >BPA</option>
                <option  >BPE</option>
                <option  >BPEd</option>
                <option  >BPharm</option>
                <option  >BPlan</option>
                <option  >BPT</option>
                <option  >BRIT - Bachelor of Radiology and Imaging Technology</option>
                <option  >BRS - Bachelor in Rehabilitation Scinece</option>
                <option  >BRT Bachelor in Rehabilitation Technology</option>
                <option  >BSc</option>
                <option  >BSc Honours </option>
                <option  >BSc Honours Agriculture</option>
                <option  >BSc MLT</option>
                <option  >BScEd</option>
                <option  >BSMS</option>
                <option  >BSW</option>
                <option  >BTech</option>
                <option  >BTHM</option>
                <option  >BTM (Honours)</option>
                <option  >BTS</option>
                <option  >BTTM</option>
                <option  >BUMS</option>
                <option  >BVA - Bachelor of Visual Arts</option>
                <option  >BVC Bachelor of Visual Communication</option>
                <option  >BVSC&amp;AH</option>
                <option  >Degree from Indian Institute of Forest Management</option>
                <option  >Degree in Special Training in Teaching HI/VI/MR</option>
                <option  >Graduation in Cardio Vascular Technology</option>
                <option  >Integrated Five Year BA,LLB Degree</option>
                <option  >Integrated Five Year BCom,LLB Degree</option>
                <option  >LLB</option>
                <option  >MBBS</option>
                <option  >Post Basic B.Sc</option>
                <option value="Bsc. - Msc. Integrated"> Bsc. - Msc. Integrated</option>
                <option value="BA - MA Integrated">BA - MA Integrated</option>
                <option value="BSMS Bachelor of Science Master of Science">BSMS Bachelor of Science Master of Science</option>
                <option value="DM">DM</option>
                <option value="DNB">DNB</option>
                <option value="LLM">LLM</option>
                <option value="M Des  Master of Design">M Des  Master of Design</option>
                <option value="MA">MA</option>
                <option value="MArch">MArch</option>
                <option value="Master in Audiology and Speech Language Pathology(MASLP)">Master in Audiology and Speech Language Pathology(MASLP)</option>
                <option value="Master in Software Engineering">Master in Software Engineering</option>
                <option value="Master of Applied Science">Master of Applied Science</option>
                <option value="Master of Communication">Master of Communication</option>
                <option value="Master of Fashion Technology">Master of Fashion Technology</option>
                <option value="Master of Health Administration">Master of Health Administration</option>
                <option value="Master of Hospital Administration">Master of Hospital Administration</option>
                <option value="Master of Human Resource Management">Master of Human Resource Management</option>
                <option value="Master of Interior  Architecture and Design">Master of Interior  Architecture and Design</option>
                <option value="Master of International Business">Master of International Business</option>
                <option value="Master of Journalism and Television Production">Master of Journalism and Television Production</option>
                <option value="Master of Management in Hospitality">Master of Management in Hospitality</option>
                <option value="Master of Occupational Therapy - MOT">Master of Occupational Therapy - MOT</option>
                <option value="Master of Public Health">Master of Public Health</option>
                <option value="Master of Rehabilitation Science">Master of Rehabilitation Science</option>
                <option value="Master of Rural Development">Master of Rural Development</option>
                <option value="Master of Technology (Pharm)">Master of Technology (Pharm)</option>
                <option value="Master of Tourism Management">Master of Tourism Management</option>
                <option value="Master of Travel and Tourism Management">Master of Travel and Tourism Management</option>
                <option value="Master of Urban and Rural Planning">Master of Urban and Rural Planning</option>
                <option value=">Master of Visual Communication">Master of Visual Communication</option>
                <option value="Master of Womens Studies">Master of Womens Studies</option>
                <option value="Masters in Business Law">Masters in Business Law</option>
                <option value="MBA">MBA</option>
                <option value="MBEM Master of Building Engineering and Management">MBEM Master of Building Engineering and Management </option>
                <option value="MCA">MCA</option>
                <option value="MCh">MCh</option>
                <option value="MCJ">MCJ</option>
                <option value="MCom">MCom</option>
                <option value="MCP Master in City Planning">MCP Master in City Planning</option>
                <option value="MD">MD</option>
                <option value="MD Homeo">MD Homeo</option>
                <option  >MD SIDHA</option>
                <option value="MD SIDHA">MD-Ayurveda</option>
                <option value="MDS">MDS</option>
                <option value="ME">ME </option>
                <option value="MEd">MEd</option>
                <option value="MFA">MFA</option>
                <option value="MFM Master of Fashion Management">MFM Master of Fashion Management</option>
                <option value="MFM Master of Financial Management">MFM Master of Financial Management</option>
                <option value="MFSc">MFSc</option>
                <option value="MHMS">MHMS</option>
                <option value="MHSc CCD">MHSc CCD</option>
                <option value="MLA Master of Landscape Architecture">MLA Master of Landscape Architecture</option>
                <option value="MLiSc">MLiSc</option>
                <option value="MPA">MPA</option>
                <option value="MPE">MPE</option>
                <option value="MPEd">MPEd</option>
                <option value="MPharm">MPharm</option>
                <option value="MPhil - Arts">MPhil - Arts</option>
                <option value="MPhil - Clinical Psychology">MPhil - Clinical Psychology</option>
                <option value="MPhil - Commerce">MPhil - Commerce</option>
                <option value="MPhil - Education">MPhil - Education</option>
                <option value="MPhil - Futures Studies">MPhil - Futures Studies</option>
                <option value="MPhil - Management Studies">MPhil - Management Studies</option>
                <option  >Mphil - Medical and Social Psychology">Mphil - Medical and Social Psychology</option>
                <option value="MPhil - Physical Education">MPhil - Physical Education</option>
                <option value="MPhil - Science">MPhil - Science</option>
                <option value="Mphil - Theatre Arts ">Mphil - Theatre Arts </option>
                <option value="MPlan">MPlan</option>
                <option value="MPT">MPT</option>
                <option value="MS Master of Science">MS Master of Science </option>
                <option value="MS Master of Surgery">MS Master of Surgery</option>
                <option value="MS Pharm">MS Pharm</option>
                <option value="MSc">MSc</option>
                <option value="MSc 5 years">MSc 5 years</option>
                <option value="MSc MLT">MSc MLT</option>
                <option value="MScEd">MScEd</option>
                <option value="MScTech">MScTech</option>
                <option value="MSW">MSW</option>
                <option value="MTA">MTA</option>
                <option value="MTech">MTech</option>
                <option value="MUD Master of Urban Design">MUD Master of Urban Design</option>
                <option value="MVA Master of Visual Arts1">MVA Master of Visual Arts</option>
                <option value="MVSc">MVSc</option>
                <option value="One Year Post Graduate Diploma in Personnel Management and Industrial Relations">One Year Post Graduate Diploma in Personnel Management and Industrial Relations</option>
                <option value="P G Diploma in Quality Assurance in Microbiology">P G Diploma in Quality Assurance in Microbiology</option>
                <option value="PDCFA">PDCFA</option>
                <option value="PG  Diploma (from Other Institutions)">PG  Diploma (from Other Institutions)</option>
                <option value="PG  Diploma (from University)">PG  Diploma (from University)</option>
                <option value="PG Certificate in  Career Educational Councelling">PG Certificate in  Career Educational Councelling</option>
                <option value="PG Certificate in Criminology and Criminal Justice Admin">PG Certificate in Criminology and Criminal Justice Admin.</option>
                <option value="PG Diploma in Accomodation Operation and Management">PG Diploma in Accomodation Operation and Management</option>
                <option value="PG Diploma in Beauty Therapy">PG Diploma in Beauty Therapy</option>
                <option value="PG Diploma in Beauty Therapy and Cosmetology">PG Diploma in Beauty Therapy and Cosmetology</option>
                <option value="PG Diploma in Clinical Perfusion">PG Diploma in Clinical Perfusion</option>
                <option value="PG Diploma in Dialysis Therapy">PG Diploma in Dialysis Therapy</option>
                <option value="PG Diploma in Food Analysis and Quality Assuarance">PG Diploma in Food Analysis and Quality Assuarance</option>
                <option value="PG Diploma in Medicine">PG Diploma in Medicine</option>
                <option value="PG Diploma in Neuro Electro Physiology">PG Diploma in Neuro Electro Physiology</option>
                <option value="PG Diploma in Plastic Processing and Testing">PG Diploma in Plastic Processing and Testing</option>
                <option value="PG Diploma in Plastic Processing Technology">PG Diploma in Plastic Processing Technology</option>
                <option value="PG Diploma in Wind Power Development">PG Diploma in Wind Power Development</option>
                <option value="PG Professional Diploma in Special Education">PG Professional Diploma in Special Education</option>
                <option value="PG Translation Diploma English-Hindi">PG Translation Diploma English-Hindi</option>
                <option value="PGDBA HR">PGDBA HR</option>
                <option value="PGDHRM">PGDHRM</option>
                <option value="PGDiploma in Dialysis Technology PGDDT">PGDiploma in Dialysis Technology PGDDT</option>
                <option value="Pharm D">Pharm D</option>
                <option value="Post Graduate Diploma in AccommodationOperation and Mngmnt">Post Graduate Diploma in AccommodationOperation and Mngmnt</option>
                <option value="Post Graduate Diploma in Anaesthesiology (DA)">Post Graduate Diploma in Anaesthesiology (DA)</option>
                <option value="Post Graduate Diploma in Applied Nutrition and Dietitics">Post Graduate Diploma in Applied Nutrition and Dietitics</option><option value="00~22000043~7">Post Graduate Diploma in Business Management</option>
                <option value="Post Graduate Diploma in Child Health">Post Graduate Diploma in Child Health</option>
                <option value="Post Graduate Diploma in Clinical Child Development">Post Graduate Diploma in Clinical Child Development</option>
                <option value="Post Graduate Diploma in Clinical Nutrition and Dietetics">Post Graduate Diploma in Clinical Nutrition and Dietetics</option>
                <option value="Post Graduate Diploma in Clinical Pathology">Post Graduate Diploma in Clinical Pathology</option>
                <option value="Post Graduate Diploma in Clinical Psychology">Post Graduate Diploma in Clinical Psychology</option>
                <option value="Post Graduate Diploma in Counselling">Post Graduate Diploma in Counselling</option>
                <option value="Post Graduate Diploma in Dairy Development">Post Graduate Diploma in Dairy Development</option>
                <option value="Post Graduate Diploma in Dairy Quality Control">Post Graduate Diploma in Dairy Quality Control</option>
                <option value="Post Graduate Diploma in Dissaster management">Post Graduate Diploma in Dissaster management</option>
                <option value="Post Graduate Diploma in eGovernance">Post Graduate Diploma in eGovernance</option>
                <option value="Post Graduate Diploma in Finance and HR Management">Post Graduate Diploma in Finance and HR Management</option>
                <option value="Post Graduate Diploma in Financial Management">Post Graduate Diploma in Financial Management</option>
                <option value="Post Graduate Diploma in Folk Dance and Cultural studies">Post Graduate Diploma in Folk Dance and Cultural studies</option>
                <option value="Post Graduate Diploma in Food Science and Technology">Post Graduate Diploma in Food Science and Technology </option>
                <option value="Post Graduate Diploma in International Business Operations">Post Graduate Diploma in International Business Operations</option>
                <option value="Post Graduate Diploma in IT Enabled Services and BPO">Post Graduate Diploma in IT Enabled Services and BPO</option>
                <option value="Post Graduate Diploma in Journalism">Post Graduate Diploma in Journalism</option>
                <option value="Post Graduate Diploma in Journalism and Communication">Post Graduate Diploma in Journalism and Communication</option>
                <option value="Post Graduate Diploma in Management">Post Graduate Diploma in Management</option>
                <option value="Post Graduate Diploma in Management (PGDM)">Post Graduate Diploma in Management (PGDM)</option>
                <option value="Post Graduate Diploma in Management of Learning Disabilities">Post Graduate Diploma in Management of Learning Disabilities</option>
                <option value="Post Graduate Diploma in Marine Technology (Mechanical)">Post Graduate Diploma in Marine Technology (Mechanical)</option>
                <option value="Post Graduate Diploma in Marketing Management">Post Graduate Diploma in Marketing Management</option>
                <option value="Post Graduate Diploma in Nutrition and Dietetics">Post Graduate Diploma in Nutrition and Dietetics</option>
                <option value="Post Graduate Diploma in Orthopaedics">Post Graduate Diploma in Orthopaedics</option>
                <option value="Post Graduate Diploma in Otorhyno Laryngology">Post Graduate Diploma in Otorhyno Laryngology</option>
                <option value="Post Graduate Diploma in Personnel Management">Post Graduate Diploma in Personnel Management</option>
                <option value="Post Graduate Diploma in Psychiatric Social Work">Post Graduate Diploma in Psychiatric Social Work</option>
                <option value="Post Graduate Diploma in Public Relations">Post Graduate Diploma in Public Relations</option>
                <option value="Post Graduate Diploma in Public Relations Management">Post Graduate Diploma in Public Relations Management</option>
                <option value="Post Graduate Diploma in Regional/City Planning">Post Graduate Diploma in Regional/City Planning</option>
                <option value="Post Graduate Diploma in Software Engineering">Post Graduate Diploma in Software Engineering</option>
                <option value="Post graduate Diploma in Town and Country Planning">Post graduate Diploma in Town and Country Planning</option>
                <option value="Post Graduate Diploma in Travel and Tourism Management">Post Graduate Diploma in Travel and Tourism Management</option>
                <option value="Professional Diploma in Clinical Psychology">Professional Diploma in Clinical Psychology</option>
            ';
    }

    function get_sslc(){
        return '<option  >AHSLC</option>
                <option  >Anglo Indian School Leaving Certificate</option>
                <option  >CBSE Xth</option>
                <option  >ICSE Xth</option>
                <option  >JTSLC</option>
                <option  >Matriculation Certificate</option>
                <option  >Secondary School Examination</option>
                <option  >SSC</option>
                <option  >SSLC</option>
                <option  >SSLC with Agricultural Optional</option>
                <option  >Standard X Equivalency</option>
                <option  >THSLC Xth</option>
            ';
    }

    function get_pre_degrees(){
        return '<option  >AHSS</option>
                <option  >CBSE XIIth</option>
                <option  >ICSE XIIth</option>
                <option  >Plus 2</option>
                <option  >Plus Two Equivalency</option>
                <option  >Pre Degree</option>
                <option  >Pre University</option>
                <option  >Senior Secondary School Examination</option>
                <option  >SSSC</option>
                <option  >THSE - XII</option>
                <option  >VHSE</option>
                <option  >VHSE Pass in Trade only for Employment Purpose</option>
            ';
    }

    function get_degrees(){
        return '<option >B Voc</option>
                <option  >BA</option>
                <option  >BA Honours</option>
                <option  >Bachelor of Audiology and Speech Language Pathology(BASLP)</option>
                <option  >Bachelor of BusineesAdministration&amp;Bachelor of Laws(Honours)</option>
                <option  >Bachelor of Design</option>
                <option  >Bachelor of Divinity</option>
                <option  >Bachelor of Occupational Therapy - BOT</option>
                <option  >Bachelor of Science BS</option>
                <option  >Bachelor of Science in Applied Sciences</option>
                <option  >Bachelor of Textile</option>
                <option  >BAL</option>
                <option  >BAM</option>
                <option  >BAMS</option>
                <option  >BArch</option>
                <option  >BBA</option>
                <option  >BBM</option>
                <option  >BBS</option>
                <option  >BBS Bachelor of Business Studies</option>
                <option  >BBT</option>
                <option  >BCA</option>
                <option  >BCJ</option>
                <option  >BCom</option>
                <option  >BComHonours</option>
                <option  >BComEd</option>
                <option  >BCS - Bachelor of Corporate Secretaryship</option>
                <option  >BCVT </option>
                <option  >BDS</option>
                <option  >BE</option>
                <option  >BEd</option>
                <option  >BFA</option>
                <option  >BFA Hearing Impaired</option>
                <option  >BFSc</option>
                <option  >BFT</option>
                <option  >BHM</option>
                <option  >BHMS</option>
                <option  >BIL Bachelor of Industrial Law</option>
                <option  >BIT</option>
                <option  >BLiSc</option>
                <option  >BMMC</option>
                <option  >BMS - Bachelor of Management Studies</option>
                <option  >BNYS</option>
                <option  >BPA</option>
                <option  >BPE</option>
                <option  >BPEd</option>
                <option  >BPharm</option>
                <option  >BPlan</option>
                <option  >BPT</option>
                <option  >BRIT - Bachelor of Radiology and Imaging Technology</option>
                <option  >BRS - Bachelor in Rehabilitation Scinece</option>
                <option  >BRT Bachelor in Rehabilitation Technology</option>
                <option  >BSc</option>
                <option  >BSc Honours </option>
                <option  >BSc Honours Agriculture</option>
                <option  >BSc MLT</option>
                <option  >BScEd</option>
                <option  >BSMS</option>
                <option  >BSW</option>
                <option  >BTech</option>
                <option  >BTHM</option>
                <option  >BTM (Honours)</option>
                <option  >BTS</option>
                <option  >BTTM</option>
                <option  >BUMS</option>
                <option  >BVA - Bachelor of Visual Arts</option>
                <option  >BVC Bachelor of Visual Communication</option>
                <option  >BVSC&amp;AH</option>
                <option  >Degree from Indian Institute of Forest Management</option>
                <option  >Degree in Special Training in Teaching HI/VI/MR</option>
                <option  >Graduation in Cardio Vascular Technology</option>
                <option  >Integrated Five Year BA,LLB Degree</option>
                <option  >Integrated Five Year BCom,LLB Degree</option>
                <option  >LLB</option>
                <option  >MBBS</option>
                <option  >Post Basic B.Sc</option>
        ';
    }
    
    function get_post_graduates(){
        return '<option value="Bsc. - Msc. Integrated"> Bsc. - Msc. Integrated</option>
                <option value="BA - MA Integrated">BA - MA Integrated</option>
                <option value="BSMS Bachelor of Science Master of Science">BSMS Bachelor of Science Master of Science</option>
                <option value="DM">DM</option>
                <option value="DNB">DNB</option>
                <option value="LLM">LLM</option>
                <option value="M Des  Master of Design">M Des  Master of Design</option>
                <option value="MA">MA</option>
                <option value="MArch">MArch</option>
                <option value="Master in Audiology and Speech Language Pathology(MASLP)">Master in Audiology and Speech Language Pathology(MASLP)</option>
                <option value="Master in Software Engineering">Master in Software Engineering</option>
                <option value="Master of Applied Science">Master of Applied Science</option>
                <option value="Master of Communication">Master of Communication</option>
                <option value="Master of Fashion Technology">Master of Fashion Technology</option>
                <option value="Master of Health Administration">Master of Health Administration</option>
                <option value="Master of Hospital Administration">Master of Hospital Administration</option>
                <option value="Master of Human Resource Management">Master of Human Resource Management</option>
                <option value="Master of Interior  Architecture and Design">Master of Interior  Architecture and Design</option>
                <option value="Master of International Business">Master of International Business</option>
                <option value="Master of Journalism and Television Production">Master of Journalism and Television Production</option>
                <option value="Master of Management in Hospitality">Master of Management in Hospitality</option>
                <option value="Master of Occupational Therapy - MOT">Master of Occupational Therapy - MOT</option>
                <option value="Master of Public Health">Master of Public Health</option>
                <option value="Master of Rehabilitation Science">Master of Rehabilitation Science</option>
                <option value="Master of Rural Development">Master of Rural Development</option>
                <option value="Master of Technology (Pharm)">Master of Technology (Pharm)</option>
                <option value="Master of Tourism Management">Master of Tourism Management</option>
                <option value="Master of Travel and Tourism Management">Master of Travel and Tourism Management</option>
                <option value="Master of Urban and Rural Planning">Master of Urban and Rural Planning</option>
                <option value=">Master of Visual Communication">Master of Visual Communication</option>
                <option value="Master of Womens Studies">Master of Womens Studies</option>
                <option value="Masters in Business Law">Masters in Business Law</option>
                <option value="MBA">MBA</option>
                <option value="MBEM Master of Building Engineering and Management">MBEM Master of Building Engineering and Management </option>
                <option value="MCA">MCA</option>
                <option value="MCh">MCh</option>
                <option value="MCJ">MCJ</option>
                <option value="MCom">MCom</option>
                <option value="MCP Master in City Planning">MCP Master in City Planning</option>
                <option value="MD">MD</option>
                <option value="MD Homeo">MD Homeo</option>
                <option  >MD SIDHA</option>
                <option value="MD SIDHA">MD-Ayurveda</option>
                <option value="MDS">MDS</option>
                <option value="ME">ME </option>
                <option value="MEd">MEd</option>
                <option value="MFA">MFA</option>
                <option value="MFM Master of Fashion Management">MFM Master of Fashion Management</option>
                <option value="MFM Master of Financial Management">MFM Master of Financial Management</option>
                <option value="MFSc">MFSc</option>
                <option value="MHMS">MHMS</option>
                <option value="MHSc CCD">MHSc CCD</option>
                <option value="MLA Master of Landscape Architecture">MLA Master of Landscape Architecture</option>
                <option value="MLiSc">MLiSc</option>
                <option value="MPA">MPA</option>
                <option value="MPE">MPE</option>
                <option value="MPEd">MPEd</option>
                <option value="MPharm">MPharm</option>
                <option value="MPhil - Arts">MPhil - Arts</option>
                <option value="MPhil - Clinical Psychology">MPhil - Clinical Psychology</option>
                <option value="MPhil - Commerce">MPhil - Commerce</option>
                <option value="MPhil - Education">MPhil - Education</option>
                <option value="MPhil - Futures Studies">MPhil - Futures Studies</option>
                <option value="MPhil - Management Studies">MPhil - Management Studies</option>
                <option  >Mphil - Medical and Social Psychology">Mphil - Medical and Social Psychology</option>
                <option value="MPhil - Physical Education">MPhil - Physical Education</option>
                <option value="MPhil - Science">MPhil - Science</option>
                <option value="Mphil - Theatre Arts ">Mphil - Theatre Arts </option>
                <option value="MPlan">MPlan</option>
                <option value="MPT">MPT</option>
                <option value="MS Master of Science">MS Master of Science </option>
                <option value="MS Master of Surgery">MS Master of Surgery</option>
                <option value="MS Pharm">MS Pharm</option>
                <option value="MSc">MSc</option>
                <option value="MSc 5 years">MSc 5 years</option>
                <option value="MSc MLT">MSc MLT</option>
                <option value="MScEd">MScEd</option>
                <option value="MScTech">MScTech</option>
                <option value="MSW">MSW</option>
                <option value="MTA">MTA</option>
                <option value="MTech">MTech</option>
                <option value="MUD Master of Urban Design">MUD Master of Urban Design</option>
                <option value="MVA Master of Visual Arts1">MVA Master of Visual Arts</option>
                <option value="MVSc">MVSc</option>
                <option value="One Year Post Graduate Diploma in Personnel Management and Industrial Relations">One Year Post Graduate Diploma in Personnel Management and Industrial Relations</option>
                <option value="P G Diploma in Quality Assurance in Microbiology">P G Diploma in Quality Assurance in Microbiology</option>
                <option value="PDCFA">PDCFA</option>
                <option value="PG  Diploma (from Other Institutions)">PG  Diploma (from Other Institutions)</option>
                <option value="PG  Diploma (from University)">PG  Diploma (from University)</option>
                <option value="PG Certificate in  Career Educational Councelling">PG Certificate in  Career Educational Councelling</option>
                <option value="PG Certificate in Criminology and Criminal Justice Admin">PG Certificate in Criminology and Criminal Justice Admin.</option>
                <option value="PG Diploma in Accomodation Operation and Management">PG Diploma in Accomodation Operation and Management</option>
                <option value="PG Diploma in Beauty Therapy">PG Diploma in Beauty Therapy</option>
                <option value="PG Diploma in Beauty Therapy and Cosmetology">PG Diploma in Beauty Therapy and Cosmetology</option>
                <option value="PG Diploma in Clinical Perfusion">PG Diploma in Clinical Perfusion</option>
                <option value="PG Diploma in Dialysis Therapy">PG Diploma in Dialysis Therapy</option>
                <option value="PG Diploma in Food Analysis and Quality Assuarance">PG Diploma in Food Analysis and Quality Assuarance</option>
                <option value="PG Diploma in Medicine">PG Diploma in Medicine</option>
                <option value="PG Diploma in Neuro Electro Physiology">PG Diploma in Neuro Electro Physiology</option>
                <option value="PG Diploma in Plastic Processing and Testing">PG Diploma in Plastic Processing and Testing</option>
                <option value="PG Diploma in Plastic Processing Technology">PG Diploma in Plastic Processing Technology</option>
                <option value="PG Diploma in Wind Power Development">PG Diploma in Wind Power Development</option>
                <option value="PG Professional Diploma in Special Education">PG Professional Diploma in Special Education</option>
                <option value="PG Translation Diploma English-Hindi">PG Translation Diploma English-Hindi</option>
                <option value="PGDBA HR">PGDBA HR</option>
                <option value="PGDHRM">PGDHRM</option>
                <option value="PGDiploma in Dialysis Technology PGDDT">PGDiploma in Dialysis Technology PGDDT</option>
                <option value="Pharm D">Pharm D</option>
                <option value="Post Graduate Diploma in AccommodationOperation and Mngmnt">Post Graduate Diploma in AccommodationOperation and Mngmnt</option>
                <option value="Post Graduate Diploma in Anaesthesiology (DA)">Post Graduate Diploma in Anaesthesiology (DA)</option>
                <option value="Post Graduate Diploma in Applied Nutrition and Dietitics">Post Graduate Diploma in Applied Nutrition and Dietitics</option><option value="00~22000043~7">Post Graduate Diploma in Business Management</option>
                <option value="Post Graduate Diploma in Child Health">Post Graduate Diploma in Child Health</option>
                <option value="Post Graduate Diploma in Clinical Child Development">Post Graduate Diploma in Clinical Child Development</option>
                <option value="Post Graduate Diploma in Clinical Nutrition and Dietetics">Post Graduate Diploma in Clinical Nutrition and Dietetics</option>
                <option value="Post Graduate Diploma in Clinical Pathology">Post Graduate Diploma in Clinical Pathology</option>
                <option value="Post Graduate Diploma in Clinical Psychology">Post Graduate Diploma in Clinical Psychology</option>
                <option value="Post Graduate Diploma in Counselling">Post Graduate Diploma in Counselling</option>
                <option value="Post Graduate Diploma in Dairy Development">Post Graduate Diploma in Dairy Development</option>
                <option value="Post Graduate Diploma in Dairy Quality Control">Post Graduate Diploma in Dairy Quality Control</option>
                <option value="Post Graduate Diploma in Dissaster management">Post Graduate Diploma in Dissaster management</option>
                <option value="Post Graduate Diploma in eGovernance">Post Graduate Diploma in eGovernance</option>
                <option value="Post Graduate Diploma in Finance and HR Management">Post Graduate Diploma in Finance and HR Management</option>
                <option value="Post Graduate Diploma in Financial Management">Post Graduate Diploma in Financial Management</option>
                <option value="Post Graduate Diploma in Folk Dance and Cultural studies">Post Graduate Diploma in Folk Dance and Cultural studies</option>
                <option value="Post Graduate Diploma in Food Science and Technology">Post Graduate Diploma in Food Science and Technology </option>
                <option value="Post Graduate Diploma in International Business Operations">Post Graduate Diploma in International Business Operations</option>
                <option value="Post Graduate Diploma in IT Enabled Services and BPO">Post Graduate Diploma in IT Enabled Services and BPO</option>
                <option value="Post Graduate Diploma in Journalism">Post Graduate Diploma in Journalism</option>
                <option value="Post Graduate Diploma in Journalism and Communication">Post Graduate Diploma in Journalism and Communication</option>
                <option value="Post Graduate Diploma in Management">Post Graduate Diploma in Management</option>
                <option value="Post Graduate Diploma in Management (PGDM)">Post Graduate Diploma in Management (PGDM)</option>
                <option value="Post Graduate Diploma in Management of Learning Disabilities">Post Graduate Diploma in Management of Learning Disabilities</option>
                <option value="Post Graduate Diploma in Marine Technology (Mechanical)">Post Graduate Diploma in Marine Technology (Mechanical)</option>
                <option value="Post Graduate Diploma in Marketing Management">Post Graduate Diploma in Marketing Management</option>
                <option value="Post Graduate Diploma in Nutrition and Dietetics">Post Graduate Diploma in Nutrition and Dietetics</option>
                <option value="Post Graduate Diploma in Orthopaedics">Post Graduate Diploma in Orthopaedics</option>
                <option value="Post Graduate Diploma in Otorhyno Laryngology">Post Graduate Diploma in Otorhyno Laryngology</option>
                <option value="Post Graduate Diploma in Personnel Management">Post Graduate Diploma in Personnel Management</option>
                <option value="Post Graduate Diploma in Psychiatric Social Work">Post Graduate Diploma in Psychiatric Social Work</option>
                <option value="Post Graduate Diploma in Public Relations">Post Graduate Diploma in Public Relations</option>
                <option value="Post Graduate Diploma in Public Relations Management">Post Graduate Diploma in Public Relations Management</option>
                <option value="Post Graduate Diploma in Regional/City Planning">Post Graduate Diploma in Regional/City Planning</option>
                <option value="Post Graduate Diploma in Software Engineering">Post Graduate Diploma in Software Engineering</option>
                <option value="Post graduate Diploma in Town and Country Planning">Post graduate Diploma in Town and Country Planning</option>
                <option value="Post Graduate Diploma in Travel and Tourism Management">Post Graduate Diploma in Travel and Tourism Management</option>
                <option value="Professional Diploma in Clinical Psychology">Professional Diploma in Clinical Psychology</option>
            ';
    }
    
?>