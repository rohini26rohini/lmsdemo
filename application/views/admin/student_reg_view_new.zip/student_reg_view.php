<div class="relative col-lg-10 col-md-9 col-sm-9 col-xs-12 ">
    <div class="white_card ">
        <h6>Add Student Details</h6>
        <hr/>
        <ul class="nav nav-pills">
            <li class="nav-item">
                <a class="nav-link active" data-toggle="pill" href="#reg1">Personal Details</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="pill" href="#reg2"> Qualifications</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="pill" href="#reg3">Others</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="pill" href="#reg4">Documents</a>
            </li>
            <li class="nav-item">
                <a class="nav-link getbatchfee" data-toggle="pill" href="#reg6">Payment</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="pill" href="#reg5">Batch Allocation</a>
            </li>
        </ul>
        <div class="tab-content"> 
            <div id="reg1" class=" tab-pane active">
                <?php $this->load->view('admin/students/student_reg_view_1'); ?>
            </div>
            <div id="reg2" class=" tab-pane fade">
                <?php $this->load->view('admin/students/student_reg_view_2'); ?>
            </div>
            <div id="reg3" class=" tab-pane fade">
                <?php $this->load->view('admin/students/student_reg_view_3'); ?>
            </div>
            <div id="reg4" class=" tab-pane fade">
                <?php $this->load->view('admin/students/student_reg_view_4'); ?>
            </div>
            <div id="reg5" class=" tab-pane fade">
                <?php $this->load->view('admin/students/student_reg_view_5'); ?>
            </div>
            <div id="reg6" class=" tab-pane fade">
                <form id="feepayment_form" method="POST">
                    <?php
                    
                    ?>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $this->load->view("admin/scripts/student_register_script"); ?>
