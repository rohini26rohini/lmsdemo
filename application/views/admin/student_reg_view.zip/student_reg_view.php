<div class="relative col-lg-10 col-md-9 col-sm-9 col-xs-12 ">
    <div class="white_card ">
        <h6>Add Student Details</h6>
        <hr/>
        <ul class="nav nav-pills">
            <li class="nav-item">
                <a class="nav-link active" data-toggle="pill" href="#reg1">Personal Details</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="pill" href="#reg2"> Qualifications</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="pill" href="#reg3">Others</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="pill" href="#reg4">Documents</a>
            </li>
            <li class="nav-item">
                <a class="nav-link getbatchfee" data-toggle="pill" href="#reg6">Payment</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="pill" href="#reg5">Batch Allocation</a>
            </li>
        </ul>
        <div class="tab-content"> 
            <div id="reg1" class=" tab-pane active">
                 <form id="personal_form" method="post" enctype="multipart/form-data">
                      <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>" />

<!--
                     <input type="hidden" id="student_id" name="student_id" value="<?php echo $studentArr['student_id'];?>"/>
                <div class="avathar_wrap">
                    <div class="avathar_img">
                        <input type="file">
                    </div>
-->


                     <input type="hidden" id="student_id" name="student_id" value="<?php echo $studentArr['student_id'];?>"/>
                     <div class="avathar_wrap">
                                    <div class="avathar_img" style="background-image: url(<?php echo base_url();?>uploads/student_images/<?php echo $studentArr['student_image'];?>);">
                                        <input type="file" name="file_name">
                                    </div>

                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

                                            <div class="form-group">
                                                <label>Course<span class="req redbold">*</span></label>
                                                <select class="form-control" name="course_id" id="course">
                                                    <option value="">Select</option>
                                                   <?php foreach($courseArr as $course){?>
                                                  <option value="<?php echo $course['class_id'];?>"
                                                          <?php if(!empty($Selectedcourse)){if($Selectedcourse['course_id'] == $course['class_id']){ echo "selected";} }?>><?php echo $course['class_name'];?></option>
                                                  <?php } ?>
                                                </select>
                                            </div>
                                        </div>

                       <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Name<span class="req redbold">*</span></label>
                                <input type="text" class="form-control" placeholder="" value="<?php echo $studentArr['name'];?>" name="name">
                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="form-group">
                                                    <label style="display:block;">Gender<span class="req redbold">*</span></label>
                                                    <div class="form-check-inline">
                                                      <label class="form-check-label">
                                                        <input type="radio" class="form-check-input" name="gender" value="male" <?php  if($studentArr['gender'] == "male"){ echo "checked";}?>>Male
                                                      </label>
                                                    </div>
                                                    <div class="form-check-inline">
                                                      <label class="form-check-label">
                                                        <input type="radio" class="form-check-input" name="gender" value="female" <?php  if($studentArr['gender'] == "female"){ echo "checked";}?>>Female
                                                      </label>
                                                    </div>

                                            </div>
                        </div>

                    </div>

                    <!-- Data Table Plugin Section Starts Here -->
                </div>

                <div class="row">
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Address<span class="req redbold">*</span></label>
                                <input type="text" class="form-control" placeholder="" value="<?php echo $studentArr['address'];?>" name="address">
                            </div>
                        </div>

                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Street Name<span class="req redbold">*</span></label>
                                <input type="text" class="form-control" placeholder="" value="<?php echo $studentArr['street'];?>" name="street">
                            </div>
                        </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="form-group">
                            <label>State<span class="req redbold">*</span></label>
                            <select class="form-control" name="state" id="state">
                                    <option value="">Select</option>
                                  <?php foreach($stateArr as $state){?>
                                  <option value="<?php echo $state['id'];?>" <?php if($state['id']==$studentArr['state']){ echo "Selected";} ?>><?php echo $state['name'];?></option>
                                  <?php } ?>
                                </select>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="form-group">
                            <label>District<span class="req redbold">*</span></label>
                            <select class="form-control" name="district" id="district">
                                <option value="">Select</option>
                                <?php
                                foreach($DistrictArr as $district){?>
                                        <option value="<?php echo $district['id'];?>" <?php if($district['id']==$studentArr['district']){ echo "Selected";} ?>><?php echo $district['name'];?></option>
                                <?php } ?>
                                                </select>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="form-group">
                            <label>Contact Number<span class="req redbold">*</span></label>
                            <input type="text" class="form-control" placeholder="" value="<?php echo $studentArr['contact_number'];?>" name="contact_number">
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="form-group">
                            <label>WhatsApp No<span class="req redbold">*</span></label>
                            <input type="text" class="form-control" placeholder="" value="<?php echo $studentArr['whatsapp_number'];?>" name="whatsapp_number">
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="form-group">
                            <label>Mobile Number<span class="req redbold">*</span></label>
                            <input type="text" class="form-control" placeholder="" value="<?php echo $studentArr['mobile_number'];?>" name="mobile_number">
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="form-group">
                            <label>Name of Guardian<span class="req redbold">*</span></label>
                            <input type="text" class="form-control" placeholder="" value="<?php echo $studentArr['guardian_name'];?>" name="guardian_name">
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="form-group">
                            <label>Email ID<span class="req redbold">*</span></label>
                            <input type="text" class="form-control" placeholder="" value="<?php echo $studentArr['email'];?>" name="email">
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="form-group">
                            <label>Date Of Birth<span class="req redbold">*</span></label>
                            <input type="text" class="form-control calendarclass" placeholder="Date Of Birth" name="date_of_birth" id="dob" value="<?php echo $studentArr['date_of_birth'] ;?>"/>
                        </div>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="form-group">
                            <button class="btn btn-info btn_save">Save</button>
                            <button class="btn btn-default btn_cancel">Cancel</button>
                        </div>
                    </div>
                </div>
                </form>
            </div>
            <div id="reg2" class=" tab-pane fade">
                <form id="qualification_form" method="post">
                <div class="row">
                     <input type="hidden" name="student_id" value="<?php echo $studentArr['student_id']; ?>"/>
                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>" />
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="form-group">
                            <label>SSLC Total Marks</label>
                            <div class="input-group input_group_form">
                                <input type="hidden" name="category[]" value="sslc" />
                        <select type="text" class="form-control" name="qualification[]">
                            <?php
                            $sslcArr=$this->common->get_student_qualification_byid($studentArr['student_id'],"sslc");


                            ?><option selected ><?php if(!empty($sslcArr['qualification'])){echo $sslcArr['qualification'];}?>
                                        <option value="">Select</option>
                                        <option  >AHSLC</option>
                                        <option  >Anglo Indian School Leaving Certificate</option>
                                        <option  >CBSE Xth</option>
                                        <option  >ICSE Xth</option>
                                        <option  >JTSLC</option>
                                        <option  >Matriculation Certificate</option>
                                        <option  >Secondary School Examination</option>
                                        <option  >SSC</option>
                                        <option  >SSLC</option>
                                        <option  >SSLC with Agricultural Optional</option>
                                        <option  >Standard X Equivalency</option>
                                        <option  >THSLC Xth</option>
                                        </select>
                                <div class="input-group-append percent_box">
                                      <input type="number" class="form-control" placeholder="(%)" name="marks[]" value="<?php if(!empty($sslcArr['marks'])) {echo $sslcArr['marks']; }?>"/>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="form-group"> <label>+2/VHSE</label>
                            <div class="input-group input_group_form">
                                 <input type="hidden" name="category[]" value="plustwo" />
                               <select  class="form-control" name="qualification[]">
                                    <?php
                            $plustwo=$this->common->get_student_qualification_byid($studentArr['student_id'],"plustwo");


                            ?><option selected ><?php if(!empty($plustwo['qualification'])){echo $plustwo['qualification'];}?></option>
                                        <option value="">Select</option>
                                        <option  >AHSS</option>
                                        <option  >CBSE XIIth</option>
                                        <option  >ICSE XIIth</option>
                                        <option  >Plus 2</option>
                                        <option  >Plus Two Equivalency</option>
                                        <option  >Pre Degree</option>
                                        <option  >Pre University</option>
                                        <option  >Senior Secondary School Examination</option>
                                        <option  >SSSC</option>
                                        <option  >THSE - XII</option>
                                        <option  >VHSE</option>
                                        <option  >VHSE Pass in Trade only for Employment Purpose</option>
                                        </select>
                                <div class="input-group-append percent_box">
                                    <input type="number" class="form-control" placeholder="(%)" name="marks[]" value="<?php if(!empty($plustwo['marks'])){ echo $plustwo['marks']; }?>"/>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="form-group"> <label>Degree</label>
                             <input type="hidden" name="category[]" value="degree" />
                            <div class="input-group input_group_form">
                                <select type="text" class="form-control" name="qualification[]">
                                  <?php
                                    $degree=$this->common->get_student_qualification_byid($studentArr['student_id'],"degree");


                            ?><option selected ><?php if(!empty($degree['qualification'])){echo $degree['qualification'];}?></option>
                                        <option value="">Select</option>
                                            <option >B Voc</option>
                                            <option  >BA</option>
                                            <option  >BA Honours</option>
                                            <option  >Bachelor of Audiology and Speech Language Pathology(BASLP)</option>
                                            <option  >Bachelor of BusineesAdministration&amp;Bachelor of Laws(Honours)</option>
                                            <option  >Bachelor of Design</option>
                                            <option  >Bachelor of Divinity</option>
                                            <option  >Bachelor of Occupational Therapy - BOT</option>
                                            <option  >Bachelor of Science BS</option>
                                            <option  >Bachelor of Science in Applied Sciences</option>
                                            <option  >Bachelor of Textile</option>
                                            <option  >BAL</option>
                                            <option  >BAM</option>
                                            <option  >BAMS</option>
                                            <option  >BArch</option>
                                            <option  >BBA</option>
                                            <option  >BBM</option>
                                            <option  >BBS</option>
                                            <option  >BBS Bachelor of Business Studies</option>
                                            <option  >BBT</option>
                                            <option  >BCA</option>
                                            <option  >BCJ</option>
                                            <option  >BCom</option>
                                            <option  >BComHonours</option>
                                            <option  >BComEd</option>
                                            <option  >BCS - Bachelor of Corporate Secretaryship</option>
                                            <option  >BCVT </option>
                                            <option  >BDS</option>
                                            <option  >BE</option>
                                            <option  >BEd</option>
                                            <option  >BFA</option>
                                            <option  >BFA Hearing Impaired</option>
                                            <option  >BFSc</option>
                                            <option  >BFT</option>
                                            <option  >BHM</option>
                                            <option  >BHMS</option>
                                            <option  >BIL Bachelor of Industrial Law</option>
                                            <option  >BIT</option>
                                            <option  >BLiSc</option>
                                            <option  >BMMC</option>
                                            <option  >BMS - Bachelor of Management Studies</option>
                                            <option  >BNYS</option>
                                            <option  >BPA</option>
                                            <option  >BPE</option>
                                            <option  >BPEd</option>
                                            <option  >BPharm</option>
                                            <option  >BPlan</option>
                                            <option  >BPT</option>
                                            <option  >BRIT - Bachelor of Radiology and Imaging Technology</option>
                                            <option  >BRS - Bachelor in Rehabilitation Scinece</option>
                                            <option  >BRT Bachelor in Rehabilitation Technology</option>
                                            <option  >BSc</option>
                                            <option  >BSc Honours </option>
                                            <option  >BSc Honours Agriculture</option>
                                            <option  >BSc MLT</option>
                                            <option  >BScEd</option>
                                            <option  >BSMS</option>
                                            <option  >BSW</option>
                                            <option  >BTech</option>
                                            <option  >BTHM</option>
                                            <option  >BTM (Honours)</option>
                                            <option  >BTS</option>
                                            <option  >BTTM</option>
                                            <option  >BUMS</option>
                                            <option  >BVA - Bachelor of Visual Arts</option>
                                            <option  >BVC Bachelor of Visual Communication</option>
                                            <option  >BVSC&amp;AH</option>
                                            <option  >Degree from Indian Institute of Forest Management</option>
                                            <option  >Degree in Special Training in Teaching HI/VI/MR</option>
                                            <option  >Graduation in Cardio Vascular Technology</option>
                                            <option  >Integrated Five Year BA,LLB Degree</option>
                                            <option  >Integrated Five Year BCom,LLB Degree</option>
                                            <option  >LLB</option>
                                            <option  >MBBS</option>
                                            <option  >Post Basic B.Sc</option>
                                        </select>
                                <div class="input-group-append percent_box">
                                   <input type="number" class="form-control" placeholder="(%)" name="marks[]" value="<?php if(!empty($degree['marks'])){ echo $degree['marks']; }?>"/>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="form-group"> <label>PG</label>
                               <input type="hidden" name="category[]" value="pg" />
                            <div class="input-group input_group_form">
                               <select type="text" class="form-control " name="qualification[]">
                                   <?php
                                    $pg=$this->common->get_student_qualification_byid($studentArr['student_id'],"pg");


                            ?><option selected ><?php if(!empty($pg['qualification'])){echo $pg['qualification'];}?></option>
                                        <option  value="" >Select</option>
                                            <option value="Bsc. - Msc. Integrated"> Bsc. - Msc. Integrated</option>
                                            <option value="BA - MA Integrated">BA - MA Integrated</option>
                                            <option value="BSMS Bachelor of Science Master of Science">BSMS Bachelor of Science Master of Science</option>
                                            <option value="DM">DM</option>
                                            <option value="DNB">DNB</option>
                                            <option value="LLM">LLM</option>
                                            <option value="M Des  Master of Design">M Des  Master of Design</option>
                                            <option value="MA">MA</option>
                                            <option value="MArch">MArch</option>
                                            <option value="Master in Audiology and Speech Language Pathology(MASLP)">Master in Audiology and Speech Language Pathology(MASLP)</option>
                                            <option value="Master in Software Engineering">Master in Software Engineering</option>
                                            <option value="Master of Applied Science">Master of Applied Science</option>
                                            <option value="Master of Communication">Master of Communication</option>
                                            <option value="Master of Fashion Technology">Master of Fashion Technology</option>
                                            <option value="Master of Health Administration">Master of Health Administration</option>
                                            <option value="Master of Hospital Administration">Master of Hospital Administration</option>
                                            <option value="Master of Human Resource Management">Master of Human Resource Management</option>
                                            <option value="Master of Interior  Architecture and Design">Master of Interior  Architecture and Design</option>
                                            <option value="Master of International Business">Master of International Business</option>
                                            <option value="Master of Journalism and Television Production">Master of Journalism and Television Production</option>
                                            <option value="Master of Management in Hospitality">Master of Management in Hospitality</option>
                                            <option value="Master of Occupational Therapy - MOT">Master of Occupational Therapy - MOT</option>
                                            <option value="Master of Public Health">Master of Public Health</option>
                                            <option value="Master of Rehabilitation Science">Master of Rehabilitation Science</option>
                                            <option value="Master of Rural Development">Master of Rural Development</option>
                                            <option value="Master of Technology (Pharm)">Master of Technology (Pharm)</option>
                                            <option value="Master of Tourism Management">Master of Tourism Management</option>
                                            <option value="Master of Travel and Tourism Management">Master of Travel and Tourism Management</option>
                                            <option value="Master of Urban and Rural Planning">Master of Urban and Rural Planning</option>
                                            <option value=">Master of Visual Communication">Master of Visual Communication</option>
                                            <option value="Master of Womens Studies">Master of Womens Studies</option>
                                            <option value="Masters in Business Law">Masters in Business Law</option>
                                            <option value="MBA">MBA</option>
                                            <option value="MBEM Master of Building Engineering and Management">MBEM Master of Building Engineering and Management </option>
                                            <option value="MCA">MCA</option>
                                            <option value="MCh">MCh</option>
                                            <option value="MCJ">MCJ</option>
                                            <option value="MCom">MCom</option>
                                            <option value="MCP Master in City Planning">MCP Master in City Planning</option>
                                            <option value="MD">MD</option>
                                            <option value="MD Homeo">MD Homeo</option>
                                            <option  >MD SIDHA</option>
                                            <option value="MD SIDHA">MD-Ayurveda</option>
                                            <option value="MDS">MDS</option>
                                            <option value="ME">ME </option>
                                            <option value="MEd">MEd</option>
                                            <option value="MFA">MFA</option>
                                            <option value="MFM Master of Fashion Management">MFM Master of Fashion Management</option>
                                            <option value="MFM Master of Financial Management">MFM Master of Financial Management</option>
                                            <option value="MFSc">MFSc</option>
                                            <option value="MHMS">MHMS</option>
                                            <option value="MHSc CCD">MHSc CCD</option>
                                            <option value="MLA Master of Landscape Architecture">MLA Master of Landscape Architecture</option>
                                            <option value="MLiSc">MLiSc</option>
                                            <option value="MPA">MPA</option>
                                            <option value="MPE">MPE</option>
                                            <option value="MPEd">MPEd</option>
                                            <option value="MPharm">MPharm</option>
                                            <option value="MPhil - Arts">MPhil - Arts</option>
                                            <option value="MPhil - Clinical Psychology">MPhil - Clinical Psychology</option>
                                            <option value="MPhil - Commerce">MPhil - Commerce</option>
                                            <option value="MPhil - Education">MPhil - Education</option>
                                            <option value="MPhil - Futures Studies">MPhil - Futures Studies</option>
                                            <option value="MPhil - Management Studies">MPhil - Management Studies</option>
                                            <option  >Mphil - Medical and Social Psychology">Mphil - Medical and Social Psychology</option>
                                            <option value="MPhil - Physical Education">MPhil - Physical Education</option>
                                            <option value="MPhil - Science">MPhil - Science</option>
                                            <option value="Mphil - Theatre Arts ">Mphil - Theatre Arts </option>
                                            <option value="MPlan">MPlan</option>
                                            <option value="MPT">MPT</option>
                                            <option value="MS Master of Science">MS Master of Science </option>
                                            <option value="MS Master of Surgery">MS Master of Surgery</option>
                                            <option value="MS Pharm">MS Pharm</option>
                                            <option value="MSc">MSc</option>
                                            <option value="MSc 5 years">MSc 5 years</option>
                                            <option value="MSc MLT">MSc MLT</option>
                                            <option value="MScEd">MScEd</option>
                                            <option value="MScTech">MScTech</option>
                                            <option value="MSW">MSW</option>
                                            <option value="MTA">MTA</option>
                                            <option value="MTech">MTech</option>
                                            <option value="MUD Master of Urban Design">MUD Master of Urban Design</option>
                                            <option value="MVA Master of Visual Arts1">MVA Master of Visual Arts</option>
                                            <option value="MVSc">MVSc</option>
                                            <option value="One Year Post Graduate Diploma in Personnel Management and Industrial Relations">One Year Post Graduate Diploma in Personnel Management and Industrial Relations</option>
                                            <option value="P G Diploma in Quality Assurance in Microbiology">P G Diploma in Quality Assurance in Microbiology</option>
                                            <option value="PDCFA">PDCFA</option>
                                            <option value="PG  Diploma (from Other Institutions)">PG  Diploma (from Other Institutions)</option>
                                            <option value="PG  Diploma (from University)">PG  Diploma (from University)</option>
                                            <option value="PG Certificate in  Career Educational Councelling">PG Certificate in  Career Educational Councelling</option>
                                            <option value="PG Certificate in Criminology and Criminal Justice Admin">PG Certificate in Criminology and Criminal Justice Admin.</option>
                                            <option value="PG Diploma in Accomodation Operation and Management">PG Diploma in Accomodation Operation and Management</option>
                                            <option value="PG Diploma in Beauty Therapy">PG Diploma in Beauty Therapy</option>
                                            <option value="PG Diploma in Beauty Therapy and Cosmetology">PG Diploma in Beauty Therapy and Cosmetology</option>
                                            <option value="PG Diploma in Clinical Perfusion">PG Diploma in Clinical Perfusion</option>
                                            <option value="PG Diploma in Dialysis Therapy">PG Diploma in Dialysis Therapy</option>
                                            <option value="PG Diploma in Food Analysis and Quality Assuarance">PG Diploma in Food Analysis and Quality Assuarance</option>
                                            <option value="PG Diploma in Medicine">PG Diploma in Medicine</option>
                                            <option value="PG Diploma in Neuro Electro Physiology">PG Diploma in Neuro Electro Physiology</option>
                                            <option value="PG Diploma in Plastic Processing and Testing">PG Diploma in Plastic Processing and Testing</option>
                                            <option value="PG Diploma in Plastic Processing Technology">PG Diploma in Plastic Processing Technology</option>
                                            <option value="PG Diploma in Wind Power Development">PG Diploma in Wind Power Development</option>
                                            <option value="PG Professional Diploma in Special Education">PG Professional Diploma in Special Education</option>
                                            <option value="PG Translation Diploma English-Hindi">PG Translation Diploma English-Hindi</option>
                                            <option value="PGDBA HR">PGDBA HR</option>
                                            <option value="PGDHRM">PGDHRM</option>
                                            <option value="PGDiploma in Dialysis Technology PGDDT">PGDiploma in Dialysis Technology PGDDT</option>
                                            <option value="Pharm D">Pharm D</option>
                                            <option value="Post Graduate Diploma in AccommodationOperation and Mngmnt">Post Graduate Diploma in AccommodationOperation and Mngmnt</option>
                                            <option value="Post Graduate Diploma in Anaesthesiology (DA)">Post Graduate Diploma in Anaesthesiology (DA)</option>
                                            <option value="Post Graduate Diploma in Applied Nutrition and Dietitics">Post Graduate Diploma in Applied Nutrition and Dietitics</option><option value="00~22000043~7">Post Graduate Diploma in Business Management</option>
                                            <option value="Post Graduate Diploma in Child Health">Post Graduate Diploma in Child Health</option>
                                            <option value="Post Graduate Diploma in Clinical Child Development">Post Graduate Diploma in Clinical Child Development</option>
                                            <option value="Post Graduate Diploma in Clinical Nutrition and Dietetics">Post Graduate Diploma in Clinical Nutrition and Dietetics</option>
                                            <option value="Post Graduate Diploma in Clinical Pathology">Post Graduate Diploma in Clinical Pathology</option>
                                            <option value="Post Graduate Diploma in Clinical Psychology">Post Graduate Diploma in Clinical Psychology</option>
                                            <option value="Post Graduate Diploma in Counselling">Post Graduate Diploma in Counselling</option>
                                            <option value="Post Graduate Diploma in Dairy Development">Post Graduate Diploma in Dairy Development</option>
                                            <option value="Post Graduate Diploma in Dairy Quality Control">Post Graduate Diploma in Dairy Quality Control</option>
                                            <option value="Post Graduate Diploma in Dissaster management">Post Graduate Diploma in Dissaster management</option>
                                            <option value="Post Graduate Diploma in eGovernance">Post Graduate Diploma in eGovernance</option>
                                            <option value="Post Graduate Diploma in Finance and HR Management">Post Graduate Diploma in Finance and HR Management</option>
                                            <option value="Post Graduate Diploma in Financial Management">Post Graduate Diploma in Financial Management</option>
                                            <option value="Post Graduate Diploma in Folk Dance and Cultural studies">Post Graduate Diploma in Folk Dance and Cultural studies</option>
                                            <option value="Post Graduate Diploma in Food Science and Technology">Post Graduate Diploma in Food Science and Technology </option>
                                            <option value="Post Graduate Diploma in International Business Operations">Post Graduate Diploma in International Business Operations</option>
                                            <option value="Post Graduate Diploma in IT Enabled Services and BPO">Post Graduate Diploma in IT Enabled Services and BPO</option>
                                            <option value="Post Graduate Diploma in Journalism">Post Graduate Diploma in Journalism</option>
                                            <option value="Post Graduate Diploma in Journalism and Communication">Post Graduate Diploma in Journalism and Communication</option>
                                            <option value="Post Graduate Diploma in Management">Post Graduate Diploma in Management</option>
                                            <option value="Post Graduate Diploma in Management (PGDM)">Post Graduate Diploma in Management (PGDM)</option>
                                            <option value="Post Graduate Diploma in Management of Learning Disabilities">Post Graduate Diploma in Management of Learning Disabilities</option>
                                            <option value="Post Graduate Diploma in Marine Technology (Mechanical)">Post Graduate Diploma in Marine Technology (Mechanical)</option>
                                            <option value="Post Graduate Diploma in Marketing Management">Post Graduate Diploma in Marketing Management</option>
                                            <option value="Post Graduate Diploma in Nutrition and Dietetics">Post Graduate Diploma in Nutrition and Dietetics</option>
                                            <option value="Post Graduate Diploma in Orthopaedics">Post Graduate Diploma in Orthopaedics</option>
                                            <option value="Post Graduate Diploma in Otorhyno Laryngology">Post Graduate Diploma in Otorhyno Laryngology</option>
                                            <option value="Post Graduate Diploma in Personnel Management">Post Graduate Diploma in Personnel Management</option>
                                            <option value="Post Graduate Diploma in Psychiatric Social Work">Post Graduate Diploma in Psychiatric Social Work</option>
                                            <option value="Post Graduate Diploma in Public Relations">Post Graduate Diploma in Public Relations</option>
                                            <option value="Post Graduate Diploma in Public Relations Management">Post Graduate Diploma in Public Relations Management</option>
                                            <option value="Post Graduate Diploma in Regional/City Planning">Post Graduate Diploma in Regional/City Planning</option>
                                            <option value="Post Graduate Diploma in Software Engineering">Post Graduate Diploma in Software Engineering</option>
                                            <option value="Post graduate Diploma in Town and Country Planning">Post graduate Diploma in Town and Country Planning</option>
                                            <option value="Post Graduate Diploma in Travel and Tourism Management">Post Graduate Diploma in Travel and Tourism Management</option>
                                            <option value="Professional Diploma in Clinical Psychology">Professional Diploma in Clinical Psychology</option>
                                        </select>
                                <div class="input-group-append percent_box">
                                    <input type="number" class="form-control" placeholder="(%)" name="marks[]"
                                            value="<?php if(!empty($pg['marks'])){ echo $plustwo['marks']; }?>"/>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="form-group"> <label>Other</label>
                            <input type="hidden" name="category[]" value="other" />
                            <div class="input-group input_group_form">
                                <?php $other=$this->common->get_student_qualification_byid($studentArr['student_id'],"other");?>
                                <input type="text" class="form-control " placeholder="Other" name="qualification[]" value="<?php if(!empty($other['qualification'])){ echo $other['qualification'];}?>"/>
                                <div class="input-group-append percent_box">
                                    <input type="number" class="form-control" placeholder="(%)" name="marks[]"
                                           value="<?php if(!empty($other['marks'])){ echo $other['marks']; }?>"/>
                                </div>
                            </div>

                        </div>
                    </div>


                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="form-group">
                            <button class="btn btn-info btn_save" type="submit">Save</button>
                            <button class="btn btn-default btn_cancel">Cancel</button>
                        </div>
                    </div>
                </div>
                </form>
            </div>
            <div id="reg3" class=" tab-pane fade">
                <form id="requirement_form" method="post">
                    <input type="hidden" name="student_id" value="<?php echo $studentArr['student_id']; ?>"/>
                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>" />
                <table class="table table_register">
                    <tbody>
                        <tr>
                            <td>Hostel Required</td>
                            <td nowrap=""><label class="custom_checkbox">Yes
                            <input type="radio" name="hostel" value="yes" class="hostel" <?php if($studentArr['hostel'] == "yes"){ echo "Checked"; } ?> >
                              <span class="checkmark"></span>
                            </label>
                            </td>
                            <td nowrap=""><label class="custom_checkbox">No
                              <input type="radio" name="hostel" class="hostel" value="no" <?php if($studentArr['hostel']=="no"){ echo "Checked"; }?>>
                              <span class="checkmark"></span>
                            </label>
                            </td>
                        </tr>

                        <tr class="hostel_sub" <?php if($studentArr['hostel'] == "no"){?> style="display:none;" <?php } ?>>
                            <td>Whether the candidate had stayed in any hostel before </td>
                            <td><label class="custom_checkbox">Yes
                              <input type="radio" name="stayed_in_hostel" value="yes" class="stayed_in_hostel" <?php if($studentArr['stayed_in_hostel'] == "yes"){ echo "Checked"; }?>>
                              <span class="checkmark"></span>
                            </label></td>
                            <td><label class="custom_checkbox">No
                              <input type="radio" name="stayed_in_hostel"  value="no" class="stayed_in_hostel" <?php if($studentArr['stayed_in_hostel'] == "no"){ echo "Checked"; }?>>
                              <span class="checkmark"></span>
                            </label></td>
                        </tr>
                        <tr  class="hostel_sub" <?php if($studentArr['hostel'] == "no"){?> style="display:none;" <?php } ?>>
                            <td>Food habit of student
                            </td>
                            <td><label class="custom_checkbox">Veg
                            <input type="radio" name="food_habit" value="veg"  class="food_habit" <?php if($studentArr['food_habit']=="veg"){echo "Checked";}?>>
                              <span class="checkmark"></span>
                            </label></td>
                            <td nowrap=""><label class="custom_checkbox">Non-Veg
                             <input type="radio" name="food_habit" value="nonveg" class="food_habit" <?php if($studentArr['food_habit']=="nonveg"){echo "Checked";}?>>
                              <span class="checkmark"></span>
                            </label></td>
                        </tr>

                        <tr>
                            <td>Whether the candidate has any medical history of aliment</td>
                            <td><label class="custom_checkbox">Yes
                              <input type="radio" name="medical_history" value="yes" <?php if($studentArr['medical_history']=="yes"){echo "Checked";}?>>
                              <span class="checkmark"></span>
                            </label></td>
                            <td><label class="custom_checkbox">No
                             <input type="radio" name="medical_history" value="no" <?php if($studentArr['medical_history']=="no"){echo "Checked";}?>>
                              <span class="checkmark"></span>
                            </label></td>
                        </tr>
                        <tr>
                            <td>Transportation Required</td>
                            <td><label class="custom_checkbox">Yes
                              <input type="radio" name="transportation" value="yes" <?php if($studentArr['transportation']=="yes"){echo "Checked";}?> class="transportation">
                              <span class="checkmark"></span>
                            </label></td>
                            <td><label class="custom_checkbox">No
                                  <input type="radio" name="transportation" value="no" <?php if($studentArr['transportation']=="no"){echo "Checked";}?> class="transportation">
                                  <span class="checkmark"></span>
                                </label></td>
                        </tr>

                        <tr id="place" <?php if($studentArr['transportation'] == "no" || $studentArr['transportation'] == ""){ ?> style="display:none;" <?php }?>>
                            <td>Place</td>
                            <td colspan="2" >
                                <div class="form-group">

                                    <input type="text" class="form-control" placeholder="Place" value="<?php echo $studentArr['place']?>" name="place" id="transport_place">
                                </div>
                            </td>
                        </tr>


                    </tbody>
                </table>
                    <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

                        <div class="form-group">
                            <button class="btn btn-info btn_save" type="submit">Save</button>
                            <button class="btn btn-default btn_cancel">Cancel</button>
                        </div>
                    </div>
                </div>
                </form>

            </div>
            <div id="reg4" class=" tab-pane fade">
               <form id="document_form" method="post" enctype="multipart/form-data">
                <div id="section_duplicate2">
                        <hr class="no_hr"/>
                   <div class="add_wrap">
                        <div class="row">
                             <input type="hidden" name="student_id" value="<?php echo $studentArr['student_id']; ?>"/>
                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>" />
                            <div class="col">
                                <div class="form-group">
                                    <label>Qualification</label>
                                    <select class="form-control" name="qualification[]">
                                      <option value="">Select</option>
                                                <option  >AHSLC</option>
                                                <option  >Anglo Indian School Leaving Certificate</option>
                                                <option  >CBSE Xth</option>
                                                <option  >ICSE Xth</option>
                                                <option  >JTSLC</option>
                                                <option  >Matriculation Certificate</option>
                                                <option  >Secondary School Examination</option>
                                                <option  >SSC</option>
                                                <option  >SSLC</option>
                                                <option  >SSLC with Agricultural Optional</option>
                                                <option  >Standard X Equivalency</option>
                                                <option  >THSLC Xth</option>
                                                <option  >AHSS</option>
                                                <option  >CBSE XIIth</option>
                                                <option  >ICSE XIIth</option>
                                                <option  >Plus 2</option>
                                                <option  >Plus Two Equivalency</option>
                                                <option  >Pre Degree</option>
                                                <option  >Pre University</option>
                                                <option  >Senior Secondary School Examination</option>
                                                <option  >SSSC</option>
                                                <option  >THSE - XII</option>
                                                <option  >VHSE</option>
                                                <option  >VHSE Pass in Trade only for Employment Purpose</option>
                                          <option >B Voc</option>
                                                    <option  >BA</option>
                                                    <option  >BA Honours</option>
                                                    <option  >Bachelor of Audiology and Speech Language Pathology(BASLP)</option>
                                                    <option  >Bachelor of BusineesAdministration&amp;Bachelor of Laws(Honours)</option>
                                                    <option  >Bachelor of Design</option>
                                                    <option  >Bachelor of Divinity</option>
                                                    <option  >Bachelor of Occupational Therapy - BOT</option>
                                                    <option  >Bachelor of Science BS</option>
                                                    <option  >Bachelor of Science in Applied Sciences</option>
                                                    <option  >Bachelor of Textile</option>
                                                    <option  >BAL</option>
                                                    <option  >BAM</option>
                                                    <option  >BAMS</option>
                                                    <option  >BArch</option>
                                                    <option  >BBA</option>
                                                    <option  >BBM</option>
                                                    <option  >BBS</option>
                                                    <option  >BBS Bachelor of Business Studies</option>
                                                    <option  >BBT</option>
                                                    <option  >BCA</option>
                                                    <option  >BCJ</option>
                                                    <option  >BCom</option>
                                                    <option  >BComHonours</option>
                                                    <option  >BComEd</option>
                                                    <option  >BCS - Bachelor of Corporate Secretaryship</option>
                                                    <option  >BCVT </option>
                                                    <option  >BDS</option>
                                                    <option  >BE</option>
                                                    <option  >BEd</option>
                                                    <option  >BFA</option>
                                                    <option  >BFA Hearing Impaired</option>
                                                    <option  >BFSc</option>
                                                    <option  >BFT</option>
                                                    <option  >BHM</option>
                                                    <option  >BHMS</option>
                                                    <option  >BIL Bachelor of Industrial Law</option>
                                                    <option  >BIT</option>
                                                    <option  >BLiSc</option>
                                                    <option  >BMMC</option>
                                                    <option  >BMS - Bachelor of Management Studies</option>
                                                    <option  >BNYS</option>
                                                    <option  >BPA</option>
                                                    <option  >BPE</option>
                                                    <option  >BPEd</option>
                                                    <option  >BPharm</option>
                                                    <option  >BPlan</option>
                                                    <option  >BPT</option>
                                                    <option  >BRIT - Bachelor of Radiology and Imaging Technology</option>
                                                    <option  >BRS - Bachelor in Rehabilitation Scinece</option>
                                                    <option  >BRT Bachelor in Rehabilitation Technology</option>
                                                    <option  >BSc</option>
                                                    <option  >BSc Honours </option>
                                                    <option  >BSc Honours Agriculture</option>
                                                    <option  >BSc MLT</option>
                                                    <option  >BScEd</option>
                                                    <option  >BSMS</option>
                                                    <option  >BSW</option>
                                                    <option  >BTech</option>
                                                    <option  >BTHM</option>
                                                    <option  >BTM (Honours)</option>
                                                    <option  >BTS</option>
                                                    <option  >BTTM</option>
                                                    <option  >BUMS</option>
                                                    <option  >BVA - Bachelor of Visual Arts</option>
                                                    <option  >BVC Bachelor of Visual Communication</option>
                                                    <option  >BVSC&amp;AH</option>
                                                    <option  >Degree from Indian Institute of Forest Management</option>
                                                    <option  >Degree in Special Training in Teaching HI/VI/MR</option>
                                                    <option  >Graduation in Cardio Vascular Technology</option>
                                                    <option  >Integrated Five Year BA,LLB Degree</option>
                                                    <option  >Integrated Five Year BCom,LLB Degree</option>
                                                    <option  >LLB</option>
                                                    <option  >MBBS</option>
                                                    <option  >Post Basic B.Sc</option>
                                        <option value="Bsc. - Msc. Integrated"> Bsc. - Msc. Integrated</option>
                                                    <option value="BA - MA Integrated">BA - MA Integrated</option>
                                                    <option value="BSMS Bachelor of Science Master of Science">BSMS Bachelor of Science Master of Science</option>
                                                    <option value="DM">DM</option>
                                                    <option value="DNB">DNB</option>
                                                    <option value="LLM">LLM</option>
                                                    <option value="M Des  Master of Design">M Des  Master of Design</option>
                                                    <option value="MA">MA</option>
                                                    <option value="MArch">MArch</option>
                                                    <option value="Master in Audiology and Speech Language Pathology(MASLP)">Master in Audiology and Speech Language Pathology(MASLP)</option>
                                                    <option value="Master in Software Engineering">Master in Software Engineering</option>
                                                    <option value="Master of Applied Science">Master of Applied Science</option>
                                                    <option value="Master of Communication">Master of Communication</option>
                                                    <option value="Master of Fashion Technology">Master of Fashion Technology</option>
                                                    <option value="Master of Health Administration">Master of Health Administration</option>
                                                    <option value="Master of Hospital Administration">Master of Hospital Administration</option>
                                                    <option value="Master of Human Resource Management">Master of Human Resource Management</option>
                                                    <option value="Master of Interior  Architecture and Design">Master of Interior  Architecture and Design</option>
                                                    <option value="Master of International Business">Master of International Business</option>
                                                    <option value="Master of Journalism and Television Production">Master of Journalism and Television Production</option>
                                                    <option value="Master of Management in Hospitality">Master of Management in Hospitality</option>
                                                    <option value="Master of Occupational Therapy - MOT">Master of Occupational Therapy - MOT</option>
                                                    <option value="Master of Public Health">Master of Public Health</option>
                                                    <option value="Master of Rehabilitation Science">Master of Rehabilitation Science</option>
                                                    <option value="Master of Rural Development">Master of Rural Development</option>
                                                    <option value="Master of Technology (Pharm)">Master of Technology (Pharm)</option>
                                                    <option value="Master of Tourism Management">Master of Tourism Management</option>
                                                    <option value="Master of Travel and Tourism Management">Master of Travel and Tourism Management</option>
                                                    <option value="Master of Urban and Rural Planning">Master of Urban and Rural Planning</option>
                                                    <option value=">Master of Visual Communication">Master of Visual Communication</option>
                                                    <option value="Master of Womens Studies">Master of Womens Studies</option>
                                                    <option value="Masters in Business Law">Masters in Business Law</option>
                                                    <option value="MBA">MBA</option>
                                                    <option value="MBEM Master of Building Engineering and Management">MBEM Master of Building Engineering and Management </option>
                                                    <option value="MCA">MCA</option>
                                                    <option value="MCh">MCh</option>
                                                    <option value="MCJ">MCJ</option>
                                                    <option value="MCom">MCom</option>
                                                    <option value="MCP Master in City Planning">MCP Master in City Planning</option>
                                                    <option value="MD">MD</option>
                                                    <option value="MD Homeo">MD Homeo</option>
                                                    <option  >MD SIDHA</option>
                                                    <option value="MD SIDHA">MD-Ayurveda</option>
                                                    <option value="MDS">MDS</option>
                                                    <option value="ME">ME </option>
                                                    <option value="MEd">MEd</option>
                                                    <option value="MFA">MFA</option>
                                                    <option value="MFM Master of Fashion Management">MFM Master of Fashion Management</option>
                                                    <option value="MFM Master of Financial Management">MFM Master of Financial Management</option>
                                                    <option value="MFSc">MFSc</option>
                                                    <option value="MHMS">MHMS</option>
                                                    <option value="MHSc CCD">MHSc CCD</option>
                                                    <option value="MLA Master of Landscape Architecture">MLA Master of Landscape Architecture</option>
                                                    <option value="MLiSc">MLiSc</option>
                                                    <option value="MPA">MPA</option>
                                                    <option value="MPE">MPE</option>
                                                    <option value="MPEd">MPEd</option>
                                                    <option value="MPharm">MPharm</option>
                                                    <option value="MPhil - Arts">MPhil - Arts</option>
                                                    <option value="MPhil - Clinical Psychology">MPhil - Clinical Psychology</option>
                                                    <option value="MPhil - Commerce">MPhil - Commerce</option>
                                                    <option value="MPhil - Education">MPhil - Education</option>
                                                    <option value="MPhil - Futures Studies">MPhil - Futures Studies</option>
                                                    <option value="MPhil - Management Studies">MPhil - Management Studies</option>
                                                    <option  >Mphil - Medical and Social Psychology">Mphil - Medical and Social Psychology</option>
                                                    <option value="MPhil - Physical Education">MPhil - Physical Education</option>
                                                    <option value="MPhil - Science">MPhil - Science</option>
                                                    <option value="Mphil - Theatre Arts ">Mphil - Theatre Arts </option>
                                                    <option value="MPlan">MPlan</option>
                                                    <option value="MPT">MPT</option>
                                                    <option value="MS Master of Science">MS Master of Science </option>
                                                    <option value="MS Master of Surgery">MS Master of Surgery</option>
                                                    <option value="MS Pharm">MS Pharm</option>
                                                    <option value="MSc">MSc</option>
                                                    <option value="MSc 5 years">MSc 5 years</option>
                                                    <option value="MSc MLT">MSc MLT</option>
                                                    <option value="MScEd">MScEd</option>
                                                    <option value="MScTech">MScTech</option>
                                                    <option value="MSW">MSW</option>
                                                    <option value="MTA">MTA</option>
                                                    <option value="MTech">MTech</option>
                                                    <option value="MUD Master of Urban Design">MUD Master of Urban Design</option>
                                                    <option value="MVA Master of Visual Arts1">MVA Master of Visual Arts</option>
                                                    <option value="MVSc">MVSc</option>
                                                    <option value="One Year Post Graduate Diploma in Personnel Management and Industrial Relations">One Year Post Graduate Diploma in Personnel Management and Industrial Relations</option>
                                                    <option value="P G Diploma in Quality Assurance in Microbiology">P G Diploma in Quality Assurance in Microbiology</option>
                                                    <option value="PDCFA">PDCFA</option>
                                                    <option value="PG  Diploma (from Other Institutions)">PG  Diploma (from Other Institutions)</option>
                                                    <option value="PG  Diploma (from University)">PG  Diploma (from University)</option>
                                                    <option value="PG Certificate in  Career Educational Councelling">PG Certificate in  Career Educational Councelling</option>
                                                    <option value="PG Certificate in Criminology and Criminal Justice Admin">PG Certificate in Criminology and Criminal Justice Admin.</option>
                                                    <option value="PG Diploma in Accomodation Operation and Management">PG Diploma in Accomodation Operation and Management</option>
                                                    <option value="PG Diploma in Beauty Therapy">PG Diploma in Beauty Therapy</option>
                                                    <option value="PG Diploma in Beauty Therapy and Cosmetology">PG Diploma in Beauty Therapy and Cosmetology</option>
                                                    <option value="PG Diploma in Clinical Perfusion">PG Diploma in Clinical Perfusion</option>
                                                    <option value="PG Diploma in Dialysis Therapy">PG Diploma in Dialysis Therapy</option>
                                                    <option value="PG Diploma in Food Analysis and Quality Assuarance">PG Diploma in Food Analysis and Quality Assuarance</option>
                                                    <option value="PG Diploma in Medicine">PG Diploma in Medicine</option>
                                                    <option value="PG Diploma in Neuro Electro Physiology">PG Diploma in Neuro Electro Physiology</option>
                                                    <option value="PG Diploma in Plastic Processing and Testing">PG Diploma in Plastic Processing and Testing</option>
                                                    <option value="PG Diploma in Plastic Processing Technology">PG Diploma in Plastic Processing Technology</option>
                                                    <option value="PG Diploma in Wind Power Development">PG Diploma in Wind Power Development</option>
                                                    <option value="PG Professional Diploma in Special Education">PG Professional Diploma in Special Education</option>
                                                    <option value="PG Translation Diploma English-Hindi">PG Translation Diploma English-Hindi</option>
                                                    <option value="PGDBA HR">PGDBA HR</option>
                                                    <option value="PGDHRM">PGDHRM</option>
                                                    <option value="PGDiploma in Dialysis Technology PGDDT">PGDiploma in Dialysis Technology PGDDT</option>
                                                    <option value="Pharm D">Pharm D</option>
                                                    <option value="Post Graduate Diploma in AccommodationOperation and Mngmnt">Post Graduate Diploma in AccommodationOperation and Mngmnt</option>
                                                    <option value="Post Graduate Diploma in Anaesthesiology (DA)">Post Graduate Diploma in Anaesthesiology (DA)</option>
                                                    <option value="Post Graduate Diploma in Applied Nutrition and Dietitics">Post Graduate Diploma in Applied Nutrition and Dietitics</option><option value="00~22000043~7">Post Graduate Diploma in Business Management</option>
                                                    <option value="Post Graduate Diploma in Child Health">Post Graduate Diploma in Child Health</option>
                                                    <option value="Post Graduate Diploma in Clinical Child Development">Post Graduate Diploma in Clinical Child Development</option>
                                                    <option value="Post Graduate Diploma in Clinical Nutrition and Dietetics">Post Graduate Diploma in Clinical Nutrition and Dietetics</option>
                                                    <option value="Post Graduate Diploma in Clinical Pathology">Post Graduate Diploma in Clinical Pathology</option>
                                                    <option value="Post Graduate Diploma in Clinical Psychology">Post Graduate Diploma in Clinical Psychology</option>
                                                    <option value="Post Graduate Diploma in Counselling">Post Graduate Diploma in Counselling</option>
                                                    <option value="Post Graduate Diploma in Dairy Development">Post Graduate Diploma in Dairy Development</option>
                                                    <option value="Post Graduate Diploma in Dairy Quality Control">Post Graduate Diploma in Dairy Quality Control</option>
                                                    <option value="Post Graduate Diploma in Dissaster management">Post Graduate Diploma in Dissaster management</option>
                                                    <option value="Post Graduate Diploma in eGovernance">Post Graduate Diploma in eGovernance</option>
                                                    <option value="Post Graduate Diploma in Finance and HR Management">Post Graduate Diploma in Finance and HR Management</option>
                                                    <option value="Post Graduate Diploma in Financial Management">Post Graduate Diploma in Financial Management</option>
                                                    <option value="Post Graduate Diploma in Folk Dance and Cultural studies">Post Graduate Diploma in Folk Dance and Cultural studies</option>
                                                    <option value="Post Graduate Diploma in Food Science and Technology">Post Graduate Diploma in Food Science and Technology </option>
                                                    <option value="Post Graduate Diploma in International Business Operations">Post Graduate Diploma in International Business Operations</option>
                                                    <option value="Post Graduate Diploma in IT Enabled Services and BPO">Post Graduate Diploma in IT Enabled Services and BPO</option>
                                                    <option value="Post Graduate Diploma in Journalism">Post Graduate Diploma in Journalism</option>
                                                    <option value="Post Graduate Diploma in Journalism and Communication">Post Graduate Diploma in Journalism and Communication</option>
                                                    <option value="Post Graduate Diploma in Management">Post Graduate Diploma in Management</option>
                                                    <option value="Post Graduate Diploma in Management (PGDM)">Post Graduate Diploma in Management (PGDM)</option>
                                                    <option value="Post Graduate Diploma in Management of Learning Disabilities">Post Graduate Diploma in Management of Learning Disabilities</option>
                                                    <option value="Post Graduate Diploma in Marine Technology (Mechanical)">Post Graduate Diploma in Marine Technology (Mechanical)</option>
                                                    <option value="Post Graduate Diploma in Marketing Management">Post Graduate Diploma in Marketing Management</option>
                                                    <option value="Post Graduate Diploma in Nutrition and Dietetics">Post Graduate Diploma in Nutrition and Dietetics</option>
                                                    <option value="Post Graduate Diploma in Orthopaedics">Post Graduate Diploma in Orthopaedics</option>
                                                    <option value="Post Graduate Diploma in Otorhyno Laryngology">Post Graduate Diploma in Otorhyno Laryngology</option>
                                                    <option value="Post Graduate Diploma in Personnel Management">Post Graduate Diploma in Personnel Management</option>
                                                    <option value="Post Graduate Diploma in Psychiatric Social Work">Post Graduate Diploma in Psychiatric Social Work</option>
                                                    <option value="Post Graduate Diploma in Public Relations">Post Graduate Diploma in Public Relations</option>
                                                    <option value="Post Graduate Diploma in Public Relations Management">Post Graduate Diploma in Public Relations Management</option>
                                                    <option value="Post Graduate Diploma in Regional/City Planning">Post Graduate Diploma in Regional/City Planning</option>
                                                    <option value="Post Graduate Diploma in Software Engineering">Post Graduate Diploma in Software Engineering</option>
                                                    <option value="Post graduate Diploma in Town and Country Planning">Post graduate Diploma in Town and Country Planning</option>
                                                    <option value="Post Graduate Diploma in Travel and Tourism Management">Post Graduate Diploma in Travel and Tourism Management</option>
                                                    <option value="Professional Diploma in Clinical Psychology">Professional Diploma in Clinical Psychology</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col">
                            <div class="form-group">
                                <label>Document Name</label>
                                  <input class="form-control" type="text" name="document_name[]" placeholder="Document Name"/>
                                </div>
                            </div>
                            <div class="col">
                            <div class="form-group">
                                <label>Upload File</label>
                                   <input type="file" class="form-control" name="file_name[]"/>
                                </div>
                            </div>
                            <div class="col">
                                    <label style="display:block">&nbsp;</label>
                                                        <div class="form-check-inline">
                                      <label class="form-check-label">
                                        <input type="radio" class="form-check-input" name="verification[]" value="1">Verified
                                      </label>
                                    </div>
                                    <div class="form-check-inline">
                                      <label class="form-check-label">
                                        <input type="radio" class="form-check-input" name="verification[]" value="0">Not Verified
                                      </label>
                                  </div>
                            </div>
                            <button type="button" class="btn btn-default add_wrap_pos" id="add_block2">
                                <i class="fa fa-plus"></i>
                            </button>
                               </div>
                       </div>
                   </div>
                   <div id="duplicate_wrapper2"></div>
                    <div class="row">
                       <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="form-group">
                                <button class="btn btn-info btn_save">Save</button>
                                <button class="btn btn-default btn_cancel">Cancel</button>
                            </div>
                       </div>
                   </div>
                </form>

            </div>
            <div id="reg5" class=" tab-pane fade">
                <form id="batchallocationform"><?php //print_r($coursecenter); ?><?php //print_r($studentcourse); ?>
                    <div class="row">
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="form-group">
                                <div class="multiselect">
                                    <div class="selectBox" >
                                        <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>" />
                                        <input type="hidden" name="student_id" value="<?php echo $studentArr['student_id']; ?>"/>
                                        <input type="hidden" name="institute_center_map_id" id="institute_center_map_id" value="<?php if(isset($studentcourse) && $studentcourse['institute_course_mapping_id']!='') { echo $studentcourse['institute_course_mapping_id'];} ?>"/>
                                        <select class="form-control branchlist" id="selectedcourse" name="selectedcourse" >
                                            <option>Select course</option>
                                            <?php
                                                if(!empty($courses)) {
                                                    foreach($courses as $course) {
                                                            $selected = '';
                                                        if(isset($studentcourse) && $course->class_id==$studentcourse['course_id']) {
                                                            $selected = 'selected="selected"';
                                                        }
                                                        echo '<option value="'.$course->class_id.'" '.$selected.'>'.$course->class_name.'</option>';
                                                    }
                                                }
                                           ?>
                                          </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="form-group">
                                <div class="multiselect">
                                    <div class="selectBox" >
                                        <select class="form-control centerlist" name="branch">
                                            <option>Select branch</option>
                                            <?php
                                                if(!empty($coursecenter)) {
                                                    foreach($coursecenter as $center) {
                                                                $cntrselect = '';
                                                            if($center->branch_master_id==$studentcourse['branch_id']) {
                                                                $cntrselect = 'selected="selected"';
                                                            }
                                                        echo '<option value="'.$center->branch_master_id.'" '.$cntrselect.'>'.$center->institute_name.'</option>';
                                                    }
                                                }
                                           ?>
                                          </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                            
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="form-group">
                                <div class="multiselect">
                                    <div class="selectBox" >
                                        <select class="form-control batchlist" name="center" id="selectedbatch" <?php  if($studentcourse['branch_id']==0) { ?> style="display:none;" <?php } ?>>
                                            <option>Select center</option>
                                            <?php
                                            if($studentcourse['center_id']!='') {
                                                $selectcenter = $this->common->get_centerby_branchcourse($studentcourse['branch_id'], $studentcourse['course_id']);
                                                if(!empty($selectcenter)) {
                                                    foreach($selectcenter as $center) {
                                                        $cntselect = ''; 
                                                        if($center->institute_course_mapping_id==$studentcourse['institute_course_mapping_id']) { $cntselect = 'selected="selected"';}
                                                        echo '<option value="'.$center->institute_course_mapping_id.'" '.$cntselect.'>'.$center->institute_name.'</option>';
                                                    }
                                                }
                                            }
                                            ?>
                                          </select>
                                    </div>
                                </div>
                            </div>
                        </div>  
    
<!--
                         <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="form-group">
                                <div class="multiselect">
                                    <div class="selectBox" >
                                        <select class="form-control feelist" name="batch" id="selectedfees" <?php if($studentcourse['batch_id']==0) {?> style="display:none;" <?php } ?>>
                                            <option>Select center</option>
                                            <?php echo $studentcourse['center_id'];
                                             if($studentcourse['batch_id']!='') {
                                                $selectbatch = $this->common->get_batchby_coursecentermapp($studentcourse['institute_course_mapping_id']);
                                                if(!empty($selectbatch)) {
                                                    foreach($selectbatch as $batch) { 
                                                        $bathselect = ''; 
                                                        if($batch['batch_id']==$studentcourse['batch_id']) { $bathselect = 'selected="selected"';}
                                                        echo '<option value="'.$batch['batch_id'].'" '.$bathselect.'>'.$batch['batch_name'].'</option>';
                                                    }
                                                } 
                                             }
                                              ?>
                                          </select>
                                    </div>
                                </div>
                            </div>
                        </div>
-->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="form-group">
                                <div class="multiselect">
                                    <div class="selectBox" >
                                        <button class="btn btn-info" type="submit">Approve</button>
                                    </div>
                                </div>
                            </div>
                        </div>    
                            </div>
                        </div>
                                 <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8 col-12" id="loadbatchdetails">
                        <div class="table-responsive table_language table_batch_details" >
                                <table class="table table-bordered table-striped table-sm">
                                    <tr>
                                        <th></th>
                                        <th>Batch</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>

                                        <th>Available Seats</th>
                                        <th>Fees</th>
                                    </tr>
                                <?php
                                    if($studentcourse['batch_id']!='') {
                                    $selectbatch = $this->common->get_batchby_coursecentermapp($studentcourse['institute_course_mapping_id']);
                                    if(!empty($selectbatch)) {
                                        foreach($selectbatch as $batch) { 
                                            $batchselect = ''; 
                                            if($batch['batch_id']==$studentcourse['batch_id']) { $batchselect = 'checked="checked"';}
                                    $studentbatch = $this->common->get_total_student($batch['batch_id']);
                                    ?>
                                    <tr>
                                        <td><input type="radio" name="batch" <?php echo $batchselect;?> value="<?php echo $batch['batch_id'];?>"/></td>
                                        <td><?php echo $batch['batch_name'];?></td>
                                        <td><?php echo date('d M Y',strtotime($batch['batch_datefrom']));?></td>
                                        <td><?php echo date('d M Y',strtotime($batch['batch_dateto']));?></td>

                                        <td><?php echo $batch['batch_capacity']-$studentbatch;?>/<?php echo $batch['batch_capacity'];?></td>
                                        <td><?php echo numberformat($batch['course_totalfee']);?></td>
                                    </tr>
                                    <?php } ?>
                                    <?php } else { ?>
                                    <tr><td colspan="6">No batch available for this course</td></tr>
                                    <?php } ?>
                                    <?php } ?>
                                </table>

                            </div>
                        </div>
                        
<!--
               
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="form-group">
                                <div class="multiselect">
                                    <div class="selectBox" >
                                        <select class="form-control branchlist">
                                            <option>Select course</option>
                                            <?php
                                                if(!empty($courses)) {
                                                    foreach($courses as $course) {
                                                        echo '<option value="'.$course->class_id.'">'.$course->class_name.'</option>';
                                                    }
                                                }
                                           ?>
                                          </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                            </div>
                        </div>
-->
                        
                        
                        
                    </div>
                </form>
            </div>
            <div id="reg6" class=" tab-pane fade">
                <form id="feepayment_form" method="POST">
                    <?php
                    
                    ?>
                </form>
            </div>

        </div>
    </div>
    <!--
<div class="progress_circle">


    <input id="one" type="radio" name="stage" checked="checked" />
    <input id="two" type="radio" name="stage" disabled/>
    <input id="three" type="radio" name="stage" disabled/>
    <input id="four" type="radio" name="stage" disabled/>
    <input id="five" type="radio" name="stage" disabled/>
    <input id="six" type="radio" name="stage" disabled/>

    <div class="stages">
        <label id="label1" for="one"><span>1</span></label>
        <label id="label2" for="two"><span>2</span></label>
        <label id="label3" for="three"><span>3</span></label>
        <label id="label4" for="four"><span>4</span></label>
        <label id="label5" for="five"><span>5</span></label>
        <label id="label6" for="six"><span>6</span></label>
    </div>

    <span class="progress_line"><span class="full_hide"><span class="full"></span></span>
    </span>





</div>-->

    <!-- Data Table Plugin Section Starts Here -->



</div>
<?php $this->load->view("admin/scripts/student_register_script"); ?>
